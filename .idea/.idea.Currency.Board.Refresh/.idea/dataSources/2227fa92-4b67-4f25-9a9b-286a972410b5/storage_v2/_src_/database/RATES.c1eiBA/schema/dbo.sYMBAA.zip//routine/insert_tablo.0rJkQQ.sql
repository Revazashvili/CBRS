CREATE procedure[dbo].[insert_tablo]
@TABLONAME varchar(50),
@TABLO_IP varchar(50),
@CCYSCHEMA varchar(50),
@mfo varchar(50),
@sc varchar(50),
@status int,
@number_len int,
@type int,
@numbers int
as
declare @tablo_name varchar(50)
declare @tabloIP varchar(50)
begin
	set @tablo_name=''
	set @tabloIP=''
	if @type=1
	begin
		if not exists(select * from [RATES_TABLO_Schema] where [TABLO_IP]=@TABLO_IP)
		begin
			insert into [RATES_TABLO_Schema] ([TABLONAME],[TABLO_IP],[CCYSCHEMA],[mfo],[sc],[status],[number_len], Id)
			values							 (@TABLONAME, @TABLO_IP, @CCYSCHEMA, @mfo, @sc, @status, @number_len, @numbers)
			select N'ტაბლო დამატებულია' as status
		end
		else
		begin
			select N'ტაბლო არ დაემატა' as status
		end
	end
	if @type=2
	begin
		select @tablo_name=[TABLO_IP], @tabloIP=[TABLONAME] from [RATES_TABLO_Schema](nolock) where TABLONAME=@TABLO_IP and [TABLO_IP] is not null
		if @tablo_name=''
		begin
			select N'ტაბლო არ არსებობს' as status
		end
		else
		begin
			select @tablo_name+N' ტაბლო არსებობს, სახელი:'+@tabloIP as status
		end
	end
	if @type=3
	begin
		delete from [RATES_TABLO_Schema] where TABLO_IP=@TABLO_IP
	end
	if @type=4
	begin
		SELECT r.[TABLONAME]
      ,r.[CCYSCHEMA]
      ,r.[CCYRATE]
      ,r.[UPDATE_TIME]
	  ,s.id
	  ,r.Queues
  FROM [RATES].[dbo].[RATES_FOR_TABLO](nolock) r left join [RATES].[dbo].[RATES_TABLO_Schema](nolock) s on  r.TABLONAME COLLATE SQL_Latin1_General_CP1_CI_AS=s.TABLONAME
	end
	if @type=5
	begin
		SELECT r.[TABLONAME]
      ,r.[CCYSCHEMA]
      ,r.[CCYRATE]
      ,r.[UPDATE_TIME]
	  ,s.id
	  ,r.Queues
  FROM [RATES].[dbo].[RATES_FOR_TABLO](nolock) r left join [RATES].[dbo].[RATES_TABLO_Schema](nolock) s on  r.TABLONAME COLLATE SQL_Latin1_General_CP1_CI_AS=s.TABLONAME
  where s.TABLO_IP=@TABLO_IP
	end
end
go

