
CREATE TRIGGER [dbo].[tbu_MTRateServiceCenters]
   ON  [dbo].[MTRateServiceCenters]
   AFTER UPDATE, INSERT
AS 
BEGIN
	SET NOCOUNT ON;
 declare @operation char(1)
 IF EXISTS (SELECT * FROM DELETED)
   set @operation = 'U'
 else
   set @operation = 'I';
 
 INSERT INTO [dbo].[MTRateServiceCentersLog]
           (SCID, MFO, SC, ScCategory, IsActive, Operation,UpdateUser)
     select i.id,
			i.MFO,
			i.SC,
			i.ScCategory,
			I.IsActive,
			@operation,
			LastUpdateUser
	   from inserted i 
END

go

