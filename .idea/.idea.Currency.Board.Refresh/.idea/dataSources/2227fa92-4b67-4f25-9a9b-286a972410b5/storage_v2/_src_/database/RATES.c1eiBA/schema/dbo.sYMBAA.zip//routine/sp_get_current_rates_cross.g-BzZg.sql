CREATE PROCEDURE [dbo].[sp_get_current_rates_cross]
AS
BEGIN
	SET NOCOUNT ON;
CREATE TABLE dbo.##CURR_RATES(
	CURR1 char(3) NULL,
	CURR2 char(3) NULL,
  --VAL_NAME nvarchar(50) NULL,
  scale int null,
	DATE_VALUE datetime NULL,
	RATE_BY5 money NULL,
	RATE_BY4 money NULL,
	RATE_BY3 money NULL,
	RATE_BY2 money NULL,
	RATE_BY1 money NULL,
	rate_market money NULL,
	RATE_SELL1 money NULL,
	RATE_SELL2 money NULL,
	RATE_SELL3 money NULL,
	RATE_SELL4 money NULL,
	RATE_SELL5 money NULL,
	RATE_NBG money NULL)
	
	insert into ##CURR_RATES(CURR1,CURR2,scale) select CURR1, CURR2, scale from dbo.cross_currencies where status in(1,3)
	update ##CURR_RATES set RATE_BY1=(select top 1 rate_by1 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=1 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_BY2=(select top 1 rate_by2 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=1 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_BY3=(select top 1 rate_by3 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=1 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_BY4=(select top 1 rate_by4 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=1 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_BY5=(select top 1 rate_by5 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=1 and date_value<=getdate() order by date_value desc)
	
	update ##CURR_RATES set RATE_sell1=(select top 1 rate_sell1 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=1 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_sell2=(select top 1 rate_sell2 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=1 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_sell3=(select top 1 rate_sell3 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=1 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_sell4=(select top 1 rate_sell4 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=1 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_sell5=(select top 1 rate_sell5 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=1 and date_value<=getdate() order by date_value desc)
	
	update ##CURR_RATES set rate_market=(select top 1 rate_market from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=1 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set rate_NBG=(select top 1 rate/scale from dbo.NBG_RATE where CURR=##CURR_RATES.CURR1 and date_value<=getdate() order by date_value desc)/(select top 1 rate/scale from dbo.NBG_RATE where CURR=##CURR_RATES.CURR2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set rate_NBG=1 where rate_NBG is null
    update ##CURR_RATES set date_value=(select top 1 date_value from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=1 and date_value<=getdate() order by date_value desc)	
    
	SELECT * from ##CURR_RATES
	drop table ##CURR_RATES
END
go

grant execute on sp_get_current_rates_cross to TREASUREAPP
go

grant execute on sp_get_current_rates_cross to [LB\TreasureRole]
go

