CREATE PROCEDURE [dbo].[sp_curr_multi]
@curr1 varchar(3),
@curr2 varchar(3),
@category int
AS
BEGIN
SET NOCOUNT ON;
declare @NBG_1 money,
        @NBG_2 money

SELECT top 1 @NBG_1=n.rate FROM [RATES].[dbo].[NBG_RATE] n where n.CURR=@curr1 and date_value<=GETDATE() order by date_value desc
SELECT top 1 @NBG_2=n.rate FROM [RATES].[dbo].[NBG_RATE] n where n.CURR=@curr2 and date_value<=GETDATE() order by date_value desc
if (@curr1='GEL' ) set @NBG_1=1
if (@curr2='GEL' ) set @NBG_2=1


 select top 1 @curr1 as cur1 ,@curr2 as cur2 ,
 valuta=(case @category  when 1 then (case when c.CURR1=@curr1 and c.CURR2=@curr2 and c.type=2 then c.RATE_SELL1
                                           when c.CURR1=@curr2 and c.CURR2=@curr1 and c.type=2 then c.RATE_BY1 
					   				  end)
						 when 2 then  (case when c.CURR1=@curr1 and c.CURR2=@curr2 and c.type=2 then c.RATE_SELL2
						 				    when c.CURR1=@curr2 and c.CURR2=@curr1 and c.type=2 then c.RATE_BY2
									  end)
						 when 3 then  (case when c.CURR1=@curr1 and c.CURR2=@curr2 and c.type=2 then c.RATE_SELL3
											when c.CURR1=@curr2 and c.CURR2=@curr1 and c.type=2 then c.RATE_BY3
									   end)
						 when 4 then  (case when c.CURR1=@curr1 and c.CURR2=@curr2 and c.type=2 then c.RATE_SELL4
											when c.CURR1=@curr2 and c.CURR2=@curr1 and c.type=2 then c.RATE_BY4
									   end)
						 when 5 then  (case when c.CURR1=@curr1 and c.CURR2=@curr2 and c.type=2 then c.RATE_SELL5
											when c.CURR1=@curr2 and c.CURR2=@curr1 and c.type=2 then c.RATE_BY5 
									   end)
											  end), 
--c.DATE_VALUE, 
@NBG_1 as NBG_1 ,@NBG_2 as NBG_2
from dbo.CURR_RATES c  
where ((c.CURR1=@curr1 and c.CURR2=@curr2) or (c.CURR1=@curr2 and c.CURR2=@curr1)) and c.type=2
order by c.DATE_VALUE desc

 

  
END
go

