CREATE FUNCTION [dbo].[get_nbg_rate_all]
(@curr1	varchar(4),
@curr2 varchar(4),
@dat datetime)
returns float
AS


BEGIN
	
DECLARE
@curr11	varchar(4),
@curr22 varchar(4),
@scale1 int,
@scale2 int,
@RATE1 float,
@RATE2 float,
@sum1 float,
@sum2 float
if(@curr1='GEL')
begin
SELECT top 1 @curr11=CURR,   @scale1=scale, @RATE1=RATE from dbo.NBG_RATE where CURR=@curr2 and date_value<@dat order by date_value desc
set @sum1=CAST ( @RATE1/@scale1 AS float )
--CAST ( @RATE1/@scale1 AS float ) 
end
else if(@curr2='GEL')
begin 
SELECT top 1 @curr11=CURR,   @scale1=scale, @RATE1=RATE from dbo.NBG_RATE where CURR=@curr1 and date_value<@dat order by date_value desc
set @sum1=CAST ( @RATE1/@scale1 AS float )
end
else
begin
SELECT top 1 @curr11=CURR,   @scale1=scale, @RATE1=RATE from dbo.NBG_RATE where CURR=@curr1 and date_value<@dat order by date_value desc
SELECT top 1 @curr22=CURR,   @scale2=scale, @RATE2=RATE from dbo.NBG_RATE where CURR=@curr2 and date_value<@dat order by date_value desc	
set @sum1=(CAST ( @RATE1/@RATE2 AS float ))*(CAST ( @scale2/@scale1 AS float ))
end

return @sum1

END



--select dbo.[get_nbg_rate_all] ('USD','HKD','2011-09-12')


go

