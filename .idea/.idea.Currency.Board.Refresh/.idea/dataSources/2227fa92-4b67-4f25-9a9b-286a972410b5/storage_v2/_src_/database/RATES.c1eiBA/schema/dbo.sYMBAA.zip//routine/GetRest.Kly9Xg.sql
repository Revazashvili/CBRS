CREATE FUNCTION [dbo].[GetRest](@mfo varchar(10),@account varchar(25),@val varchar(4),@dat datetime) 
RETURNS money
AS
BEGIN
  declare @rest money
  select top 1 @rest=rest from [offline].rs_accounts.dbo.ACC_RESTS where mfo=@mfo and account=@account and val=@val and rdate<=@dat order by rdate desc
	if @rest is null set  @rest=0     

  RETURN @rest
END
go

