CREATE PROCEDURE [dbo].[sp_cont_dast_temp]
@id int,
@op_name varchar(20)
AS
BEGIN
declare @val varchar(3)
declare @dat datetime
declare @dat1 datetime
declare @rate money
declare @rat1 money

declare @scale int
declare @scale1 int

SET NOCOUNT ON;
  declare @op_type int
  select @op_type=OP_TYPE from dbo.control where ID=@id
  if @op_type=5 or @op_type=20
                 begin
                   declare curs cursor for select CURR, date_value, scale, rate from dbo.NBG_RATE_temp where ID=@id
                   open curs 
                   fetch next from curs into @val, @dat, @scale, @rate
                   while @@FETCH_STATUS=0
                   begin
                     set @rat1=null
                     select top 1 @rat1=rate,@scale1=scale,@dat1=date_value from dbo.NBG_RATE where CURR=@val and date_value<=@dat order by date_value desc
                     if (@rat1!=@rate or @scale!=@scale1)or(@rat1 is null)
                       if @dat1!=@dat or @dat1 is null
                         insert into dbo.NBG_RATE(CURR, date_value, scale, rate,ID) values(@val,@dat,@scale,@rate,@id)
                                            
                       else
                         update NBG_RATE set scale=@scale,rate=@rate where CURR=@val and date_value=@dat
                         
                       if exists(select RATE from LBANK..BANK.NBG_RATES where CURRENCY=@val and  date_value=@dat)
                         update LBANK..BANK.NBG_RATES set rate=@rate,scale=@scale where CURRENCY=@val and  date_value=@dat
                       else
                         insert into LBANK..BANK.NBG_RATES(currency, rate, scale, date_value)
                                        values(@val,@rate, @scale,@dat)  
                       
                       if exists(select rate_nbg from PIBANK..IBANKXDB.NBG_HIST where VAL=@val and  date_value=@dat)
                         update PIBANK..IBANKXDB.NBG_HIST set rate_nbg=@rate,scale=@scale where VAL=@val and  date_value=@dat
                       else
                         insert into PIBANK..IBANKXDB.NBG_HIST(VAL, rate_nbg, scale, date_value)
                                        values(@val,@rate, @scale,@dat)  
                       
                       /*if exists(select rate_nbg from LBREP..LBINFO.NBG_HIST where VAL=@val and  date_value=@dat)
                         update LBREP..LBINFO.NBG_HIST set rate_nbg=@rate,scale=@scale where VAL=@val and  date_value=@dat
                       else
                         insert into LBREP..LBINFO.NBG_HIST(VAL, rate_nbg, scale, date_value)
                                        values(@val,@rate, @scale,@dat)                   
                         */                
                     fetch next from curs into @val, @dat, @scale, @rate    
                   end
                   deallocate curs
                   insert into dbo.cont_log(ID, oper, operacia) values(@id,@op_name,convert(varchar(3),@OP_TYPE)+N' - ოპერაციის დადასტურება')
                   update control set status=1,cont_oper=@op_name,en_date=getdate() where ID=@id
                   if @@error=0
                     select 1  as result
                   else
                     select -1  as result
                 end
  else
    if @op_type=10 begin
                     set @op_type=20   
                   end 
  
  
  
END
/*
insert into PIBANK..IBANKXDB.NBG_HIST(date_value, val, rate_nbg, scale)
select date_value, CURR, rate, scale from dbo.NBG_RATE ns
where not exists(select VAL from PIBANK..IBANKXDB.NBG_HIST no where ns.DATE_VALUE=no.date_value and ns.CURR=no.val)


insert into PIBANK..IBANKXDB.NBG_HIST(date_value, val, rate_nbg, scale)
select date_value, val, RATE_NBG, scale from dbo.NBG_HIST ns
where not exists(select VAL from PIBANK..IBANKXDB.NBG_HIST no where ns.DATE_VALUE=no.date_value and ns.val=no.val)
*/
go

grant execute on sp_cont_dast_temp to rati
go

