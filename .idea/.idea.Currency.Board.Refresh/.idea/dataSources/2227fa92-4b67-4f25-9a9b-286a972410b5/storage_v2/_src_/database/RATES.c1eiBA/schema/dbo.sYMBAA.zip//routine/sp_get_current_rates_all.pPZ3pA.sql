CREATE PROCEDURE [dbo].[sp_get_current_rates_all]
@curency1 varchar(5) = null,
@curency2 varchar(5) = null,
@tuf int = 0   

-- @tuf = 0 მხოლოდ ინტერნეტ ბანკის კურსები ლართან მიმართებაში,  
-- @tuf = 1 ყველა კურსი ლართანაც, ერთამანეთთანაც  (თუ დასაშვებია) 
-- @tuf = 2 პარამეტრად გადმოცემული @curency1 და @curency2 ვალუტას შორის არსებული კურსი, 
-- @tuf = 3 ყველა კურსი ლართანაც, ერთამანეთთანაც  (თუ დასაშვებია) + შებრუნებულებიც,
AS
BEGIN
	DECLARE @date DATE = GETDATE()

    IF(@curency1 IS NULL AND @curency2 IS NOT NULL) OR (@curency1 IS NOT NULL AND @curency2 IS NULL  )
	BEGIN
		RAISERROR(N'გთხოვთ კურსები ან ორივე შეიყვანეთ, ან ორივე დატოვეთ ცარიელი.', 16,1)
	END
			
	SELECT @date = MAX(date_value)   
	FROM [RATES].[dbo].[NBG_RATE] 
	WHERE cast(date_value as date) <= ISNULL(@date, cast(GETDATE() as date) )

	DECLARE @prevDate DATETIME = dateadd(DD, -1, @date) 

    DECLARE @returned_CURR_RATES TABLE
	  (
		Currency1 CHAR(3) NULL,
		Currency2 CHAR(3) NULL,  
		Scale INT null,
		DateValue DATETIME NULL,
		RateBuy1 MONEY NULL,
		RateBuy2 MONEY NULL,
		RateBuy3 MONEY NULL,
		RateBuy4 MONEY NULL,
		RateBuy5 MONEY NULL,
		RateSell1 MONEY NULL,
		RateSell2 MONEY NULL,
		RateSell3 MONEY NULL,
		RateSell4 MONEY NULL,
		RateSell5 MONEY NULL,
		RateMarket MONEY NULL,	
		RateNBG MONEY NULL,
		Priority INT,
		Name NVARCHAR(100),
		Name2 NVARCHAR(100),
		Scale2 INT null,
		Priority2 INT null,
		RateNBGPrevius MONEY null
		)
	INSERT INTO @returned_CURR_RATES
	SELECT c.[CURR1] AS Currency1
		,c.[CURR2] AS Currency2
		, ISNULL(cr.scale, p.[scale] ) AS Scale
		,c.[DATE_VALUE] AS DateValue
		,c.[RATE_BY1] AS RateBuy1
		,c.[RATE_BY2] AS RateBuy2
		,c.[RATE_BY3] AS RateBuy3
		,c.[RATE_BY4] AS RateBuy4
		,c.[RATE_BY5] AS RateBuy5      
		,c.[RATE_SELL1] AS RateSell1
		,c.[RATE_SELL2] AS RateSell2
		,c.[RATE_SELL3] AS RateSell3
		,c.[RATE_SELL4] AS RateSell4
		,c.[RATE_SELL5] AS RateSell5
		,c.[rate_market] AS RateMarket
		,CASE WHEN c.CURR2 ='GEL' 
			 THEN (SELECT TOP 1 rate 
				   FROM dbo.NBG_RATE 
				   WHERE CURR = c.CURR1 and date_value <= @date
				   ORDER BY date_value DESC) 
			ELSE (SELECT TOP 1 rate/scale 
				  FROM dbo.NBG_RATE 
				  WHERE CURR = c.CURR1 and date_value <= @date 
				  ORDER BY date_value DESC)/(SELECT TOP 1 rate/scale 
											 FROM dbo.NBG_RATE 
											 WHERE CURR = c.CURR2 and date_value <= @date
											 ORDER BY date_value DESC)
		END AS RateNBG	 
		,CASE WHEN cr.CURR1 IS NULL THEN p.priority ELSE 100 END AS Priority
		,p.name AS Name
		,p2.name AS Name2
		,p2.scale AS Scale2
		,p2.priority AS Priority2
		,CASE WHEN c.CURR2 ='GEL' 
			  THEN (SELECT TOP 1 rate 
					from dbo.NBG_RATE 
					where CURR=c.CURR1 and date_value <= @prevDate
					order by date_value desc) else null end AS RateNBGPrevius
	FROM [RATES].[dbo].[CURR_RATES_LIVE] c
	INNER JOIN [RATES].[dbo].[CURRENCY] p ON (c.CURR1=p.CURR)
	LEFT JOIN [RATES].[dbo].[CURRENCY] p2 ON (c.CURR2=p2.CURR)
	LEFT JOIN [RATES].[dbo].[cross_currencies] cr ON (c.CURR1 = cr.CURR1 AND c.CURR2 = cr.CURR2)		
	WHERE ((@tuf=0 AND c.CURR2 = 'GEL' AND p.show_in_ib = 1)
		OR (@tuf = 1) 						
		OR (@tuf = 2 
			AND	((c.CURR1 = @curency1 and c.CURR2 = @curency2) 
				OR 
				(c.CURR1 = @curency2 and c.CURR2 = @curency1)))
		OR (@tuf = 3))
		AND c.type = 2
				   
	IF @tuf = 3
		BEGIN
			SELECT * 
			FROM
			(SELECT t1.Currency1,
				t1.Currency2,  
				t1.Scale,
				t1.DateValue,
				t1.RateBuy1,
				t1.RateBuy2,
				t1.RateBuy3,
				t1.RateBuy4,
				t1.RateBuy5,
				t1.RateSell1,
				t1.RateSell2,
				t1.RateSell3,
				t1.RateSell4,
				t1.RateSell5,
				t1.RateMarket,	
				t1.RateNBG,
				t1.Priority,
				t1.Name,
				t1.RateNBG - t1.RateNBGPrevius as  Change             
				FROM @returned_CURR_RATES t1  
				UNION ALL
				SELECT 	t1.Currency2 AS Currency1,
				t1.Currency1 AS Currency2,  
				t1.Scale2 AS Scale,
				t1.DateValue,
				1.0/(t1.RateSell1/CAST(t1.Scale AS MONEY)) * t1.Scale2  AS RateBuy1,
				1.0/(t1.RateSell2/CAST(t1.Scale AS MONEY)) * t1.Scale2  AS RateBuy2,
				1.0/(t1.RateSell3/CAST(t1.Scale AS MONEY)) * t1.Scale2   AS RateBuy3,
				1.0/(t1.RateSell4/CAST(t1.Scale AS MONEY)) * t1.Scale2   AS RateBuy4,
				1.0/(t1.RateSell5/CAST(t1.Scale AS MONEY)) * t1.Scale2   AS RateBuy5,	
				1.0/(t1.RateBuy1/CAST(t1.Scale AS MONEY)) * t1.Scale2   AS RateSell1,
				1.0/(t1.RateBuy2/CAST(t1.Scale AS MONEY)) * t1.Scale2   AS RateSell2,
				1.0/(t1.RateBuy3/CAST(t1.Scale AS MONEY)) * t1.Scale2   AS RateSell3,
				1.0/(t1.RateBuy4/CAST(t1.Scale AS MONEY)) * t1.Scale2   AS RateSell4,
				1.0/(t1.RateBuy5/CAST(t1.Scale AS MONEY)) * t1.Scale2   AS RateSell5,							
				1.0/(t1.RateMarket/CAST(t1.Scale AS MONEY)) * t1.Scale2   AS RateMarket,	
				1.0/(t1.RateNBG/CAST(t1.Scale AS MONEY)) * t1.Scale2   AS RateNBG,										
				t1.Priority2 AS Priority,									
				t1.Name2 AS Name,
				null as Change
				FROM @returned_CURR_RATES t1) g
				ORDER BY g.Priority
		END
		ELSE
		BEGIN
			SELECT 	
			t1.Currency1,
			t1.Currency2,  
			t1.Scale,
			t1.DateValue,
			t1.RateBuy1,
			t1.RateBuy2,
			t1.RateBuy3,
			t1.RateBuy4,
			t1.RateBuy5,
			t1.RateSell1,
			t1.RateSell2,
			t1.RateSell3,
			t1.RateSell4,
			t1.RateSell5,
			t1.RateMarket,	
			t1.RateNBG,
			t1.Priority,
			t1.Name,
			--t1.RateNBGPrevius,
			case when @date =  cast(GETDATE() as date) then   t1.RateNBG - t1.RateNBGPrevius else null end as  Change                 
			FROM @returned_CURR_RATES t1  
			ORDER BY t1.Priority
		END
END
go

