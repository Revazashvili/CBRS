CREATE procedure [dbo].[sp_get_currency]
@mfo varchar(10),
@sc int,
@curr varchar(3)
as
  select *,(select priority from RATES.dbo.CURRENCY where CURR=sc_permisiebles.parameter) as priorit,
           (select ACCOUNT from dbo.SC_ACCOUNT where SC_ID=sc_permisiebles.id and CURR=sc_permisiebles.parameter and acc_TYPE=1) as cash_acc,
           (select ACCOUNT from dbo.SC_ACCOUNT where SC_ID=sc_permisiebles.id and CURR=sc_permisiebles.parameter and acc_TYPE=2) as OVP_ACC from 
           CORP_PROFILE.dbo.sc_permisiebles where PER_TYPE='UNIT_CURRENCY' and mfo=@mfo and sc=@sc
  and (exists(select CURR1 from RATES.dbo.cross_currencies where (CURR2=@curr and CURR1=sc_permisiebles.parameter) or 
                                                                 (CURR1=@curr and CURR2=sc_permisiebles.parameter)
                                                                  or sc_permisiebles.parameter='GEL') 
                                                                  or @curr='GEL')
  order by priorit

go

