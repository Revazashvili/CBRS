
create FUNCTION [dbo].[get_ora_date](@dat datetime) 
RETURNS varchar(70)
AS
BEGIN
	declare @ss varchar(70)
	declare @time varchar(15)
	declare @hh int

	set @time=convert(varchar(10),@dat,8)
	set @hh=convert(int,subsTRing(@time,1,2))
	if @hh=0
	  set @time='12'+substring(@time,3,10)+' AM'
	  ELSE
	   if @hh=12
		   set @time='12'+substring(@time,3,10)+' PM'
		   else 
		     if @hh<12
		       set @time=convert(varchar(2),@hh)+substring(@time,3,10)+' AM'
		     else
		       set @time=convert(varchar(2),@hh-12)+substring(@time,3,10)+' PM'
  
  set @ss='to_date('''''+convert(varchar(10),@dat,103)+'_'+@time+''''',''''dd/mm/yyyy_hh:mi:ss AM'''')'		       
	
	RETURN @SS
END
go

