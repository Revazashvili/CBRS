/****** Script for SelectTopNRows command from SSMS  ******/
CREATE procedure [dbo].[sync_ib_convert]
as
declare @datt datetime
select @datt=MAX(date_carry) from [RATES].[dbo].[convertaciebi] where TYPE='P'  and sc=200

--Old Ibank
insert into [RATES].[dbo].[convertaciebi]( MFO, sc, date_carry, oper, shem, shem_val, gas, gas_val, appkey, rate, rate_nbg, gv, sax, pirn, sabn, ert, rate_nbg2, status, oper_name, TYPE, ert2, spec_kurs)

select pay_MFO
      ,200
      ,t.TIMESTMP
      ,t.CUSTOMER_ID
      ,t.IN_AMOUNT
      ,t.PAY_CUR
      ,t.OUT_AMOUNT
      ,t.REC_CUR
      ,t.TRNSREFNR
      ,t.SPECIAL_RATE
      ,dbo.get_nbg_ratef(t.PAY_CUR,'GEL',convert(date,t.validafter))
      ,t.CUST_NAME
      ,t.CUST_NAME
      ,t.PIN
      ,null
      ,t.SCALE
      ,dbo.get_nbg_ratef(t.REC_CUR,'GEL',convert(date,t.validafter))
      ,0
      ,t.CUST_NAME
      ,'P'
      ,1
      ,case when t.STANDART_RATE=t.SPECIAL_RATE then 0 else 1 end from pibank..IBANKXDB.TRANSFER40 t
      where t.STATUS=25 and t.TIMESTMP>@datt--convert(date,getdate())


--new IBANK
       select @datt=ISNULL(MAX(date_carry),'01jan2015') from [RATES].[dbo].[convertaciebi] where TYPE='P'  and sc=700
  
       insert into [RATES].[dbo].[convertaciebi]( MFO, sc, date_carry, oper, shem, shem_val, gas, gas_val, appkey, rate, rate_nbg, gv, sax, pirn, sabn, ert, rate_nbg2, status, oper_name, TYPE, ert2, spec_kurs)

       select    t.orderingbankcode,
                 700,
                 t.valuedate,
                 t.creatorid,
                 db.bpamount,
                 db.currency,
                 cr.bpamount,
                 cr.currency,
                 t.bpid,
                 case when db.currency='GEL' then db.bpamount/cr.bpamount else cr.bpamount/db.bpamount end,
                 dbo.get_nbg_ratef(db.currency,'GEL',convert(date,t.valuedate)),
                 t.orderingname,
                 t.orderingname,
                 t.orderingtaxcode,
                 '',
                 1,
                 dbo.get_nbg_ratef(cr.currency,'GEL',convert(date,t.valuedate)),
                 1,
                 t.orderingname,
                 'P',
                 1,
                 0
          from   lbank..LB.BP_BUSINESSPROCESSES t
       inner join lbank..LB.BP_BPAMOUNTS db 
               on t.bpid=db.bpid 
              and db.bpamounttypeid=6
       inner join lbank..LB.BP_BPAMOUNTS  cr 
               on t.bpid=cr.bpid
              and cr.bpamounttypeid=7
       where  t.bptypeid=99039  and t.valuedate>@datt and t.bpstatusid=10;

go

