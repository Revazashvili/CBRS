create PROCEDURE [dbo].[prc_get_commercial_rates]
(
	@date     datetime,
	@category tinyint
)
AS
BEGIN

declare @result 
as TABLE 
(
    [Category]	tinyint,
	[Currency1] char(3),
	[Currency2] char(3),
	[Scale]     decimal(18,4),
	[Priority]  decimal(18,4),
	[BuyRate]   decimal(18,4),
	[SellRate]  decimal(18,4),
	[ValueDate] datetime,
	[Cross]		bit
) 

    
    --gadmotanilia [dbo].[sp_get_current_rates_unagdo]-dan da [dbo].[sp_get_current_rates_cross_unagdo]-dan
	insert into @result([Category],[Currency1],[Currency2],[Scale],[Priority],[Cross])
	     select a.parameter,c.[CURR], 'GEL' CURR2, c.[scale], c.[priority], 0 
		   from dbo.CURRENCY c
		   join CORP_PROFILE.dbo.GEN_DETAIL a 
		     on HEADER='SCFXCAT' and (a.[parameter]=@category or @category is null)
		  where [status] in (2,3)
		  order by a.parameter,c.[priority]
	insert into @result([Category],[Currency1],[Currency2],[Scale],[Priority],[Cross]) 
	     select a.parameter,[CURR1], cc.[CURR2], cc.[scale],c.[priority], 1 
		   from dbo.cross_currencies cc
		   join dbo.CURRENCY c
		     on c.CURR = cc.CURR1
		   join CORP_PROFILE.dbo.GEN_DETAIL a 
		     on HEADER='SCFXCAT' and (a.[parameter]=@category or @category is null)
		  where cc.[status] in(2,3)
		  order by a.parameter,c.[priority]
    
    update @result set [BuyRate]   = (select top 1 case [category] when 1 then rate_by1 when 2 then rate_by2 when 3 then rate_by3 when 4 then rate_by4 when 5 then rate_by1  else null end from dbo.CURR_RATES where CURR1=[Currency1] and CURR2=[Currency2] and [type]=2 and date_value<=@date order by date_value desc);
	update @result set [SellRate]  = (select top 1 case [category] when 1 then rate_sell1 when 2 then rate_sell2 when 3 then rate_sell3 when 4 then rate_sell4 when 5 then rate_sell1  else null end from dbo.CURR_RATES where CURR1=[Currency1]   and CURR2=[Currency2] and [type]=2 and date_value<=@date order by date_value desc);
	update @result set [ValueDate] = (select top 1 date_value from dbo.CURR_RATES where CURR1=[Currency1] and CURR2=[Currency2] and [type]=2 and date_value<=@date order by date_value desc)
	
	delete @result 
	 where [Category]  is null
		or [Currency1] is null
		or [Currency2] is null
		or [Scale]     is null
		or [Priority]  is null
		or [BuyRate]   is null
		or [SellRate]  is null
		or [ValueDate] is null
		or [Cross]	   is null;
	select * from @result
END

/*
USE [RATES]
GO

DECLARE @RC int
DECLARE @date datetime
DECLARE @category tinyint

-- TODO: Set parameter values here.
set @date= getdate()
set @category = null

EXECUTE @RC = [dbo].[prc_get_commercial_rates] 
   @date
  ,@category
GO
*/
go

grant execute on prc_get_commercial_rates to [LB\TreasureRole]
go

grant execute on prc_get_commercial_rates to [LB\CurrencyRates_svc]
go

