-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sync_UB_convert]
	
AS
BEGIN
	
	SET NOCOUNT ON;
	
	declare @datt datetime
	set @datt=GETDATE()
select @datt=MAX(date_carry) from [RATES].[dbo].[convertaciebi] where TYPE='K'
if @datt is null
set @datt=GETDATE()
set @datt=convert(varchar(10), @datt,120)

insert into [RATES].[dbo].[convertaciebi]( MFO, sc, date_carry, oper, shem, shem_val, gas, gas_val, appkey, rate, rate_nbg, gv, sax, pirn, sabn, ert, rate_nbg2, status, oper_name, 
TYPE, ert2, spec_kurs,CITIZENSHIP,ADDRESS,CREATE_DATE)
SELECT  sc.MFO,
sc.SC,
p.operation_date
,p.insert_user_ID,
p.amount,
p.parameter_1
,p.charge_amount,
p.parameter_2,
p.order_number,
p.parameter_3,
  case when p.parameter_1<>'GEL' then (SELECT top 1 rate/scale from [RATES].[dbo].[NBG_RATE] where CURR=p.parameter_1 and date_value<=p.operation_date  order by date_value desc)
  else 1 end,
  p.last_name,
  p.first_name,
  p.PIN,
  SUBSTRING(p.additional_data,P1.pos+1,P2.pos-P1.pos-1)
  ,1,
  case when p.parameter_2<>'GEL' then (SELECT top 1 rate/scale from [RATES].[dbo].[NBG_RATE] where CURR=p.parameter_2 and date_value<=p.operation_date  order by date_value desc)
  else 1 end,
  1,
  u.username+' '+u.f_name+' '+u.l_name,
  'K',
  1,
  0,(select top 1 g.par_text from [UtilityB].[dbo].[GEN_DETAIL] g where g.HEADER='COUNTRY' and g.description= SUBSTRING(p.additional_data,p3.pos+1,P4.pos-p3.pos-1)),
  SUBSTRING(p.additional_data,1,P1.pos-1),trx_date
  FROM [UtilityB].[dbo].[payments](nolock) p
  inner join CORP_PROFILE.dbo.SC_PAR(nolock) sc on sc.ID = p.office_id
  inner join UtilityB.dbo.users(nolock) u on u.user_id=p.insert_user_ID
  
  cross apply (select (charindex(';', p.additional_data))) as P1(Pos)
  cross apply (select (charindex(';', p.additional_data, P1.Pos+1))) as P2(Pos)
  cross apply (select (charindex(';', p.additional_data, P2.Pos+1))) as P3(Pos)
  cross apply (select (charindex(';', p.additional_data, P3.Pos+1))) as P4(Pos)
  cross apply (select (charindex(';', p.additional_data, P4.Pos+1))) as P5(Pos)
  cross apply (select (charindex(';', p.additional_data, P5.Pos+1))) as P6(Pos)
  where provider_ID=7474 and payment_status=2  and p.operation_date>=@datt
  and not exists (select ID from [RATES].[dbo].[convertaciebi] where TYPE='K' and appkey=p.order_number)
  
  
  select @datt=MAX(date_carry) from [RATES].[dbo].[convertaciebi] where TYPE='E'
if @datt is null
set @datt=GETDATE()
set @datt=convert(varchar(10), @datt,120)
 
 insert into [RATES].[dbo].[convertaciebi]( MFO, sc, date_carry, oper, shem, shem_val, gas, gas_val, appkey, rate, rate_nbg, gv, sax, pirn, sabn, ert, rate_nbg2, status, oper_name, 
TYPE, ert2, spec_kurs,CITIZENSHIP,ADDRESS)
    select case when p.Pay_bank_code='' then (select mfo from remotepayments.dbo.UsersAccounts a where a.account_id=p.account_id) else p.Pay_bank_code end,0,p.Oper_Date,8890,p.Pay_Ammount,p.currency1,
  ROUND( p.Pay_Ammount*p.rate1,2),p.currency2,p.payment_id,p.rate1,p.rate2,case when p.Pay_Name='' then (select name from  remotepayments.dbo.Users a where a.user_id=p.user_id) else  substring( p.Pay_Name,PATINDEX('%,%',p.Pay_Name)+1,LEN(p.Pay_Name)-PATINDEX('%,%',p.Pay_Name) ) end,
  '',
  case when p.Pay_Name='' then (select a.INN from  remotepayments.dbo.Users a where a.user_id=p.user_id) else  substring( p.Pay_Name,1,PATINDEX('%,%',p.Pay_Name)-1 ) end,
  '',1,p.rateNGB,1,'remote Payment','E',1,0,'',''
  from [RemotePayments].[dbo].[Payments] p
  where p.operation_type=5 and p.Oper_Date>=@datt
  and not exists (select ID from [RATES].[dbo].[convertaciebi] where TYPE='E' and appkey=p.payment_id)
END
go

