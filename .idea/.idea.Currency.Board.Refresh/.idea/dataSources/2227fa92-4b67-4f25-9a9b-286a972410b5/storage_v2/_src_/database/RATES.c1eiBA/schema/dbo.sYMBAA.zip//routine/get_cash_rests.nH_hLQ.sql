CREATE procedure get_cash_rests
@stdate date,@endate date
as
declare @ss varchar(1000)

create table ##tempp(mfo varchar(10),
depart   int,
account  varchar(25),
currency varchar(5),
balance  varchar(5),
rest money,
rdate    date)


set @ss='select mfo,depart,account,currency,balance,c.rdate,lbinfo.getrest(t.account_id,t.currency,c.rdate) rest from lbinfo.ACC_RESTS t,lbinfo.calendar c 
      where t.BALANCE in(''1003'',''1006'',''1005'',''1013'',''1015'',''1016'') and status=1 and c.rdate>=to_date('''+CONVERT(varchar(10),@stdate,103)+''',''dd/mm/yyyy'') and c.rdate<=to_date('''+CONVERT(varchar(10),@endate,103)+''',''dd/mm/yyyy'') and  lbinfo.getrest(t.account_id,t.currency,c.rdate)!=0'


insert into ##tempp(mfo,depart,account,currency,balance ,rdate,rest)
exec(@ss) at LBREP
select * from  ##tempp
drop table ##tempp

--get_cash_rests '06/01/2012','06/25/2012'
go

