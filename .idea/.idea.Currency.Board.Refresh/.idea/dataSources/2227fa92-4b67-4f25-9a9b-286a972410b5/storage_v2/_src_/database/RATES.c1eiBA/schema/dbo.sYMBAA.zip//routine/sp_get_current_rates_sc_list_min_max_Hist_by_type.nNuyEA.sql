
CREATE PROCEDURE [dbo].[sp_get_current_rates_sc_list_min_max_Hist_by_type]
	@mfo varchar(10),
	@sc int,
	@type int,
	@currency varchar(3),
	@dat_from datetime,
	@date_to datetime,
	@min_max_type int
AS
BEGIN	
	SET NOCOUNT ON;
    declare @fxcat int
	set @fxcat=dbo.sp_get_fx_cat(@mfo,@sc)
    -- Insert statements for procedure here
    if @min_max_type=0
		SELECT DATE_VALUE,CURR1,CURR2,scale,RATE_BUY_min,RATE_BUY_max,RATE_SELL_min,RATE_SELL_max,RATE_NBG from RATE_HIST_MIN_MAX where CURR1=@currency and DATE_VALUE between @dat_from and @date_to and FXcategory=@fxcat and type=@type
	if @min_max_type=1
		SELECT DATE_VALUE,CURR1,CURR2,scale,RATE_BUY_min as Rate_Min,RATE_BUY_max as Rate_max,RATE_NBG from RATE_HIST_MIN_MAX where CURR1=@currency and DATE_VALUE between @dat_from and @date_to and FXcategory=@fxcat and type=@type
	if @min_max_type=2
		SELECT DATE_VALUE,CURR1,CURR2,scale,RATE_SELL_min as Rate_Min,RATE_SELL_max as Rate_max,RATE_NBG from RATE_HIST_MIN_MAX where CURR1=@currency and DATE_VALUE between @dat_from and @date_to and FXcategory=@fxcat and type=@type
END
go

grant execute on sp_get_current_rates_sc_list_min_max_Hist_by_type to current_rates_user
go

