CREATE PROCEDURE [dbo].[sp_get_nbg_rates_history]/*sp_get_nbg_rates_history*/
@datefrom DATE,
@dateto DATE,
@currencies NVARCHAR(max)   -- magalitad 'RUB,USD,EUR'
AS
BEGIN
 SET @datefrom = CAST(@datefrom AS DATE);
 SET @dateto = CAST(@dateto AS DATE);
 
 --old select
 --SELECT  
 --      r1.[CURR] AS Currency
 --     ,r1.[date_value] AS DateValue
 --     ,r1.[scale] as Scale
 --     ,r1.[rate] as Rate
 --     ,r1.[id]    as Id
 -- FROM [RATES].[dbo].[NBG_RATE] r1  
 -- WHERE r1.CURR in (SELECT * FROM [RATES].[dbo].[splitstring] (@currencies)) and r1.date_value >= @datefrom and r1.date_value <= @dateto
 -- ORDER BY r1.[CURR], r1.[date_value]
 /*
 --new logic to fill missing weekend days
	DECLARE @temptable TABLE (realDate DATETIME, mappedDate DATETIME);

	WITH theDates AS
		 (SELECT @datefrom AS theDate
		  UNION ALL
		  SELECT DATEADD(day, 1, theDate)
			FROM theDates
		   WHERE DATEADD(day, 1, theDate) <= @dateto
		 )
	INSERT INTO @temptable
	SELECT theDate,
		CASE
			WHEN DATEPART(dw,theDate) = 1 THEN DATEADD(day, -1, theDate)
			WHEN DATEPART(dw,theDate) = 2 THEN DATEADD(day, -2, theDate)
			ELSE theDate
		END mappedDate
	  FROM theDates
	OPTION (MAXRECURSION 0)

	SELECT  
		   r1.[CURR] AS Currency
		  ,realDate AS DateValue
		  ,r1.[scale] AS Scale
		  ,r1.[rate] AS Rate
		  ,r1.[id] AS Id
	FROM [RATES].[dbo].[NBG_RATE] r1
	inner join @temptable on r1.date_value = mappedDate
	WHERE r1.CURR in (SELECT * FROM [RATES].[dbo].[splitstring] (@currencies))
	ORDER BY r1.[CURR], realDate 

       */
	
	-- new logic for rest days too
	DECLARE @temptable TABLE (realDate DATE, mappedDate DATE);

	WITH theDates AS
		 (SELECT @datefrom AS theDate
		  UNION ALL
		  SELECT DATEADD(day, 1, theDate)
			FROM theDates
		   WHERE DATEADD(day, 1, theDate) <= @dateto
		 )
	INSERT INTO @temptable
	SELECT t.theDate,
              (select max([date_value]) from [RATES].[dbo].[NBG_RATE] tt where tt.date_value <=t.theDate) as mappedDate
	  FROM theDates t
	OPTION (MAXRECURSION 0)

	SELECT  
		   r1.[CURR] AS Currency
		  ,realDate AS DateValue
		  ,r1.[scale] AS Scale
		  ,r1.[rate] AS Rate
		  ,r1.[id] AS Id
	FROM [RATES].[dbo].[NBG_RATE] r1
	inner join @temptable on r1.date_value = mappedDate
	WHERE r1.CURR in (SELECT * FROM [RATES].[dbo].[splitstring] (@currencies))
	ORDER BY r1.[CURR], realDate 
END
go

