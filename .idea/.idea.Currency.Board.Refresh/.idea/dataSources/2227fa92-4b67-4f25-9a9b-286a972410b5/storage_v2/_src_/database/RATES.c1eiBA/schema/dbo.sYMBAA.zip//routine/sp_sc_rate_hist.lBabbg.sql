CREATE PROCEDURE [dbo].[sp_sc_rate_hist]
@cat int,
@st_date datetime,
@en_date datetime,
@curr1 varchar(4),
@curr2 varchar(4)
AS
BEGIN
	SET NOCOUNT ON;
	if @cat!=0
	begin
	      SELECT type,(select top 1 CASE @cat WHEN 1 THEN dbo.CURR_RATES.rate_by1 
                                 WHEN 2 THEN dbo.CURR_RATES.rate_by2 
                                 WHEN 3 THEN dbo.CURR_RATES.rate_by3
                                 WHEN 4 THEN dbo.CURR_RATES.rate_by4 
                                 WHEN 5 THEN dbo.CURR_RATES.rate_by5 END from curr_rates  where cont_id=CR1.cont_id and CURR1=CR1.CURR1 and CURR2=CR1.CURR2 and type=cr1.type order by curr_rates.DATE_VALUE desc) AS rate_by, 
               (select top 1 CASE @cat WHEN 1 THEN dbo.CURR_RATES.rate_sell1 
                                 WHEN 2 THEN dbo.CURR_RATES.rate_sell2 
                                 WHEN 3 THEN dbo.CURR_RATES.rate_sell3
                                 WHEN 4 THEN dbo.CURR_RATES.rate_sell4 
                                 WHEN 5 THEN dbo.CURR_RATES.rate_sell5 END from curr_rates where cont_id=CR1.cont_id and CURR1=CR1.CURR1 and CURR2=CR1.CURR2 and type=cr1.type order by curr_rates.DATE_VALUE desc) AS rate_sell, 
               @cat as category,CR1.CURR1,CR1.CURR2,CR1.DATE_VALUE
        FROM dbo.CURR_RATES CR1 where DATE_VALUE>=@st_date and DATE_VALUE<=@en_date and curr1=@curr1 and curr2=@curr2 order by DATE_VALUE,type
  end
  else   
    SELECT type,(select dbo.CURR_RATES.rate_by1 from curr_rates  where cont_id=CR1.cont_id and CURR1=CR1.CURR1 and CURR2=CR1.CURR2 and type=cr1.type) AS rate_by, 
           (select dbo.CURR_RATES.rate_sell1 from curr_rates where cont_id=CR1.cont_id and CURR1=CR1.CURR1 and CURR2=CR1.CURR2 and type=cr1.type) AS rate_sell, 
           1 as category,CR1.CURR1,CR1.CURR2,CR1.DATE_VALUE
        FROM dbo.CURR_RATES CR1 where DATE_VALUE>=@st_date and DATE_VALUE<=@en_date and curr1=@curr1 and curr2=@curr2 
   union     
     SELECT type,(select dbo.CURR_RATES.rate_by2 from curr_rates  where cont_id=CR1.cont_id and CURR1=CR1.CURR1 and CURR2=CR1.CURR2 and type=cr1.type) AS rate_by, 
           (select dbo.CURR_RATES.rate_sell2 from curr_rates where cont_id=CR1.cont_id and CURR1=CR1.CURR1 and CURR2=CR1.CURR2 and type=cr1.type) AS rate_sell, 
           2 as category,CR1.CURR1,CR1.CURR2,CR1.DATE_VALUE
        FROM dbo.CURR_RATES CR1 where DATE_VALUE>=@st_date and DATE_VALUE<=@en_date and curr1=@curr1 and curr2=@curr2 
   union     
     SELECT type,(select dbo.CURR_RATES.rate_by3 from curr_rates  where cont_id=CR1.cont_id and CURR1=CR1.CURR1 and CURR2=CR1.CURR2 and type=cr1.type) AS rate_by, 
           (select dbo.CURR_RATES.rate_sell3 from curr_rates where cont_id=CR1.cont_id and CURR1=CR1.CURR1 and CURR2=CR1.CURR2 and type=cr1.type) AS rate_sell, 
           3 as category,CR1.CURR1,CR1.CURR2,CR1.DATE_VALUE
        FROM dbo.CURR_RATES CR1 where DATE_VALUE>=@st_date and DATE_VALUE<=@en_date and curr1=@curr1 and curr2=@curr2 
  union     
     SELECT type,(select dbo.CURR_RATES.rate_by4 from curr_rates  where cont_id=CR1.cont_id and CURR1=CR1.CURR1 and CURR2=CR1.CURR2 and type=cr1.type) AS rate_by, 
           (select dbo.CURR_RATES.rate_sell4 from curr_rates where cont_id=CR1.cont_id and CURR1=CR1.CURR1 and CURR2=CR1.CURR2 and type=cr1.type) AS rate_sell, 
           4 as category,CR1.CURR1,CR1.CURR2,CR1.DATE_VALUE
        FROM dbo.CURR_RATES CR1 where DATE_VALUE>=@st_date and DATE_VALUE<=@en_date and curr1=@curr1 and curr2=@curr2 
  union     
     SELECT type,(select dbo.CURR_RATES.rate_by5 from curr_rates  where cont_id=CR1.cont_id and CURR1=CR1.CURR1 and CURR2=CR1.CURR2 and type=cr1.type) AS rate_by, 
           (select dbo.CURR_RATES.rate_sell5 from curr_rates where cont_id=CR1.cont_id and CURR1=CR1.CURR1 and CURR2=CR1.CURR2 and type=cr1.type) AS rate_sell, 
           5 as category,CR1.CURR1,CR1.CURR2,CR1.DATE_VALUE
        FROM dbo.CURR_RATES CR1 where DATE_VALUE>=@st_date and DATE_VALUE<=@en_date and curr1=@curr1 and curr2=@curr2 
 order by DATE_VALUE ,type                       
END
go

grant execute on sp_sc_rate_hist to TREASUREAPP
go

grant execute on sp_sc_rate_hist to [LB\TreasureRole]
go

