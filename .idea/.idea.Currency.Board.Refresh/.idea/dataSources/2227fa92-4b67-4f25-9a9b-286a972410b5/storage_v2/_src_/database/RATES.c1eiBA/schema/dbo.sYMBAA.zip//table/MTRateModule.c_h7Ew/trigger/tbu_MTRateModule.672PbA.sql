CREATE TRIGGER [dbo].[tbu_MTRateModule]
   ON  [dbo].[MTRateModule]
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	INSERT INTO [dbo].[MTRateModule_LOG]
           ([ModuleID]
           ,[ModuleStatus]
		   ,[UpdateUser])
     select ID,
			ModuleStatus,
			LastUpdateUser
       from inserted
END
go

