CREATE TRIGGER [dbo].[tbu_MTRatePairs]
   ON  [dbo].[MTRatePairs]
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	update MTRatePairs set [RowVersion]=m.[RowVersion]+1
	  from MTRatePairs m
	  join deleted d
	    on d.id = m.id
	  join inserted i
	    on i.id=d.id 
       and not(i.[Status]=d.[Status] and i.CurrentRateID=d.CurrentRateID)

 INSERT INTO [dbo].[MTRatePairsStatusChangeLog]
           ([PairID]
           ,[CurrentRateID]
           ,[Status]
		   ,[UpdateUser])
     select i.id,
			i.[CurrentRateID],
			i.[Status],
			i.[LastUpdateUser]
	   from inserted i 
	   join deleted d 
	     on d.id = i.id
        and d.[Status]!=i.[Status]

END
go

