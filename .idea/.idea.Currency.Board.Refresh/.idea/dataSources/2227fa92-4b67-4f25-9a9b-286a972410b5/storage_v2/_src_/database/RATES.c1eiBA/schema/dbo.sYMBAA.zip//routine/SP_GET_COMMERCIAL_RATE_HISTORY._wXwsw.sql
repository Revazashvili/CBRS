CREATE PROCEDURE SP_GET_COMMERCIAL_RATE_HISTORY(@dateFrom DATE, @dateTo DATETIME = NULL, @currencies NVARCHAR(MAX))
AS
BEGIN
    SET @dateTo = ISNULL(@dateTo, GETDATE())
	IF(@dateFrom IS NULL)
	BEGIN
	    RETURN
	END

	SELECT a.Currency1,
       a.Currency2,
       a.DateValue,
       a.Scale,
       a.RateSell1,
       a.RateBuy1,
       a.RateSell2,
       a.RateBuy2,
       a.RateSell3,
       a.RateBuy3,
       a.RateSell4,
       a.RateBuy4,
       a.RateSell5,
       a.RateBuy5,
       a.RateMarket,
       a.Change,
       a.RateNBG,	
	   CASE WHEN cr.CURR1 IS NULL THEN p.priority ELSE 100 END AS Priority,
	   p.name Name
	FROM(
	SELECT c.CURR1 Currency1
		,c.CURR2 Currency2
		,DATE_VALUE DateValue
		,c.scale Scale
		,RATE_SELL1 RateSell1
		,RATE_BY1 RateBuy1
		,RATE_SELL2 RateSell2
		,RATE_BY2 RateBuy2
		,RATE_SELL3 RateSell3
		,RATE_BY3 RateBuy3
		,RATE_SELL4 RateSell4
		,RATE_BY4 RateBuy4
		,RATE_SELL5 RateSell5
		,RATE_BY5 RateBuy5
		,rate_market RateMarket
		,NULL Change
		,RATE_NBG RateNBG
		,ROW_NUMBER() OVER (PARTITION BY c.CURR1, c.CURR2, CAST(DATE_VALUE AS DATE) ORDER BY DATE_VALUE DESC) row_num
	FROM dbo.CURR_RATES c
	WHERE DATE_VALUE BETWEEN @dateFrom AND @dateTo AND c.CURR2 = 'GEL' AND c.CURR1 in (SELECT * FROM [RATES].[dbo].[splitstring] (@currencies))) a
	INNER JOIN [RATES].[dbo].[CURRENCY] p ON (a.Currency1=p.CURR)
	LEFT JOIN [RATES].[dbo].[cross_currencies] cr ON (a.Currency1 = cr.CURR1 AND a.Currency2 = cr.CURR2)
	WHERE a.row_num = 1
	ORDER BY a.Currency1, a.Currency2, a.DateValue DESC

END
go

