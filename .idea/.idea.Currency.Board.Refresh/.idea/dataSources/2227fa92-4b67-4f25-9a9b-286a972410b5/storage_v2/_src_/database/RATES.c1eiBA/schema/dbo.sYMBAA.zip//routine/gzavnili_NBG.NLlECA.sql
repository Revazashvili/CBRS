-- =============================================
-- Author:		<Author,,Gela Kobuladze>
-- Create date: <Create Date,,>
-- Description:	<Description,,gzavnilebi romlis tanxac metia @clt_amount_Usd-ze (monacemebs cers maka bitsadzis cxrilshi)>
-- =============================================
CREATE PROCEDURE [dbo].[gzavnili_NBG]
	as
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
 declare @clt_amount_Usd varchar(7);
 declare @day_count varchar(2);
 declare @query varchar(5000);
 set @clt_amount_Usd = '20000';
 set @day_count='0';
 set @query='select a.currency,a.sendamount,lbinfo.get_nbg_rate(decode(a.currency,''RUR'',''RUB'',a.currency),a.transferdate),a.sname||'' ''||a.ssurname ,decode(a.sendingtype,''S'',cu.prvtnum,''''),a.rname||'' ''||a.rsurname,decode(a.sendingtype,''R'',cu.prvtnum,''''),mop.name,trunc(a.transferdate),a.transferdate,a.transferdate  from mttransfer.sendt a,mttransfer.clnuser cu,mttransfer.mtoper mop where a.transferdate>=trunc(sysdate-'+@day_count+') and a.status_code in (50) and a.clientid=cu.clientid and a.mtoper_id=mop.id and a.currency!=''GEL'' and a.sendamount*lbinfo.get_nbg_rate(decode(a.currency,''RUR'',''RUB'',a.currency),a.transferdate)>='+@clt_amount_Usd+'*lbinfo.get_nbg_rate( ''USD'',sysdate)';
 --print @query;
    insert into rates.dbo.NBG_cash_op(currency,Amount,kursi,pay_name,PID,fioclient,paperseries,ground,date_value,documentdate,closedate)
    exec (@query) at LBREP;
END
go

