create PROCEDURE [dbo].[sp_get_current_rates_cross_unagdo]
AS
BEGIN
	SET NOCOUNT ON;
	--declare @discount money
	--select @discount=back_rate from dbo.processing_margin where id=1
CREATE TABLE dbo.##CURR_RATES(
	CURR1 char(3) NULL,
	CURR2 char(3) NULL,
  --VAL_NAME nvarchar(50) NULL,
  scale float null,
	DATE_VALUE datetime NULL,
	RATE_BY5 money NULL,
	RATE_BY4 money NULL,
	RATE_BY3 money NULL,
	RATE_BY2 money NULL,
	RATE_BY1 money NULL,
	rate_market money NULL,
	RATE_SELL1 money NULL,
	RATE_SELL2 money NULL,
	RATE_SELL3 money NULL,
	RATE_SELL4 money NULL,
	RATE_SELL5 money NULL,
	RATE_NBG float NULL,
	SCALE_COMERCIAL int,
	processing int null)
	
	insert into ##CURR_RATES(CURR1,CURR2,SCALE_COMERCIAL,scale) select CURR1, CURR2, scale,scale from dbo.cross_currencies where status in(2,3)
	
	
	update ##CURR_RATES set processing=(case when ##CURR_RATES.CURR1 in (select curr from CURRENCY where processing=1) and ##CURR_RATES.CURR2 in (select curr from CURRENCY where processing=1) then 1 else 0 end)
	update ##CURR_RATES set RATE_BY1=(select top 1 rate_by1 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_BY2=(select top 1 rate_by2 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_BY3=(select top 1 rate_by3 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=2 and date_value<=getdate() order by date_value desc)
	--update ##CURR_RATES set RATE_BY3=RATE_BY3-RATE_BY3*@discount/100
	update ##CURR_RATES set RATE_BY4=(select top 1 rate_by4 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_BY5=(select top 1 rate_by5 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=2 and date_value<=getdate() order by date_value desc)
	
	update ##CURR_RATES set RATE_sell1=(select top 1 rate_sell1 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_sell2=(select top 1 rate_sell2 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_sell3=(select top 1 rate_sell3 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=2 and date_value<=getdate() order by date_value desc)
	--update ##CURR_RATES set RATE_sell3=RATE_sell3+RATE_sell3*@discount/100
	update ##CURR_RATES set RATE_sell4=(select top 1 rate_sell4 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_sell5=(select top 1 rate_sell5 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=2 and date_value<=getdate() order by date_value desc)
	
	update ##CURR_RATES set rate_market=(select top 1 rate_market from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=2 and date_value<=getdate() order by date_value desc)
	
	
	
	update ##CURR_RATES set rate_NBG=round(((select top 1 cast((rate) as float) from dbo.NBG_RATE where CURR=##CURR_RATES.CURR1 and date_value<=getdate() order by date_value desc)/
	(select top 1 cast(rate as float) from dbo.NBG_RATE where CURR=##CURR_RATES.CURR2 and date_value<=getdate() order by date_value desc))
	
	*((select top 1 cast(scale as float) from dbo.NBG_RATE where CURR=##CURR_RATES.CURR2 and date_value<=getdate() order by date_value desc)/
	(select top 1 cast(scale as float) from dbo.NBG_RATE where CURR=##CURR_RATES.CURR1 and date_value<=getdate() order by date_value desc))
	,4)
	
	
	
	
	--update ##CURR_RATES set scale=1000
	update ##CURR_RATES set rate_NBG=1 where rate_NBG is null
    update ##CURR_RATES set date_value=(select top 1 date_value from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=2 and date_value<=getdate() order by date_value desc)	
    
	SELECT * from ##CURR_RATES
	drop table ##CURR_RATES
END
go

grant execute on sp_get_current_rates_cross_unagdo to TREASUREAPP
go

grant execute on sp_get_current_rates_cross_unagdo to [LB\TreasureRole]
go

