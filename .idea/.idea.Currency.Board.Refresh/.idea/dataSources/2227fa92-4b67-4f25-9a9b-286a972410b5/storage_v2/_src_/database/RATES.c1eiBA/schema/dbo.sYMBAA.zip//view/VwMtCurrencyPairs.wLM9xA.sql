



CREATE VIEW [dbo].[VwMtCurrencyPairs]
AS
   
   select TOP 100 percent *, CURR1+'/'+CURR2 PairCode from
   (
	SELECT distinct r.CURR1,r.CURR2,r.scale, c.[priority]+c1.[priority] [priority]
	  FROM [dbo].[cross_currencies] r
	  join dbo.CURRENCY c
	    on c.CURR = r.CURR1
	  join dbo.CURRENCY c1
	    on c1.CURR = r.CURR2
	 where r.status in (1,3)
	   and ( 
	         r.CURR1 in ('USD', 'EUR', 'RUB')
			 or 
		     r.CURR2 in ('USD', 'EUR', 'RUB')
           )
     union 
    select CURR CURR1, 'GEL' CURR2, scale, c.[priority] priority from dbo.CURRENCY c where c.[status] in (1,3) and CURR in ('USD', 'EUR', 'RUB')
    ) b


go

grant insert, select, update on VwMtCurrencyPairs to [LB\TreasureRole]
go

