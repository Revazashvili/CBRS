CREATE PROCEDURE [dbo].[get_top_40_rests]
@m int,
@y int
AS
BEGIN
  SET NOCOUNT ON;	
  select t.mfo,t.account,t.currency,t.name,perc,c.date,dbo.GetRest(t.mfo,t.account,t.currency,c.DATE) as Rest from [offline].datahouse.dbo.calen c,dbo.top_40 t
  where t.status=1 and c.DATE>=(select st_date from [offline].datahouse.dbo.calen_month where YEAR=@y and MONTH=@m) and DATE<=(select en_date from [offline].datahouse.dbo.calen_month where YEAR=@y and MONTH=@m)
END
go

grant execute on get_top_40_rests to TREASUREAPP
go

grant execute on get_top_40_rests to [LB\TreasureRole]
go

