-- =============================================
-- Author:		<david gvarishvili>
-- Description:	<currency rates auto update service sql and oracle sync>
-- =============================================
CREATE PROCEDURE [dbo].[sp_get_rates_for_sync]
 @cont_id bigint
AS
BEGIN
	
	select * from 
	(SELECT [CURR1],[CURR2],[DATE_VALUE],[scale],[RATE_BY1],[RATE_SELL1],[RATE_NBG],1 as fx_category FROM [RATES].[dbo].[CURR_RATES]
	  where cont_id=@cont_id and type=2
	  union
	SELECT [CURR1],[CURR2],[DATE_VALUE],[scale],[RATE_BY2],[RATE_SELL2],[RATE_NBG],2 as fx_category FROM [RATES].[dbo].[CURR_RATES]
	  where cont_id=@cont_id and type=2  
	  union
	SELECT [CURR1],[CURR2],[DATE_VALUE],[scale],[RATE_BY3],[RATE_SELL3],[RATE_NBG],3 as fx_category FROM [RATES].[dbo].[CURR_RATES]
	  where cont_id=@cont_id and type=2  
	  union
	SELECT [CURR1],[CURR2],[DATE_VALUE],[scale],[RATE_BY4],[RATE_SELL4],[RATE_NBG],4 as fx_category FROM [RATES].[dbo].[CURR_RATES]
	  where cont_id=@cont_id and type=2  
	  union
	SELECT [CURR1],[CURR2],[DATE_VALUE],[scale],[RATE_BY5],[RATE_SELL5],[RATE_NBG],5 as fx_category FROM [RATES].[dbo].[CURR_RATES]
	  where cont_id=@cont_id and type=2) t
END
go

grant execute on sp_get_rates_for_sync to [LB\CurrencyRates_svc]
go

