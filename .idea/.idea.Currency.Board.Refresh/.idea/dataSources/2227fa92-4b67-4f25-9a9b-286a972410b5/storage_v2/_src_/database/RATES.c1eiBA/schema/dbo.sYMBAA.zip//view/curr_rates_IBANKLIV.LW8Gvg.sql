CREATE VIEW [dbo].[curr_rates_IBANKLIV]
AS
SELECT     dbo.CURR_RATES.type, dbo.CURR_RATES.CURR1, dbo.CURR_RATES.CURR2, dbo.CURR_RATES.DATE_VALUE, dbo.CURR_RATES.scale, 
                      dbo.CURR_RATES.RATE_BY5, dbo.CURR_RATES.RATE_BY4, dbo.CURR_RATES.RATE_BY3, dbo.CURR_RATES.RATE_BY2, 
                      dbo.CURR_RATES.RATE_BY1, dbo.CURR_RATES.rate_market, dbo.CURR_RATES.RATE_SELL1, dbo.CURR_RATES.RATE_SELL2, 
                      dbo.CURR_RATES.RATE_SELL3, dbo.CURR_RATES.RATE_SELL4, dbo.CURR_RATES.RATE_SELL5, dbo.CURR_RATES.RATE_NBG, 
                      dbo.CURR_RATES.ENT_DATE, dbo.CURR_RATES.cont_id, CURR_RATES_1.fx_category, CURR_RATES_1.RATE_BY, 
                      CURR_RATES_1.RATE_NBG AS rate_nbg_o, CURR_RATES_1.RATE_SELL, CURR_RATES_1.DATE_VALUE AS ora_DATE_VALUE
FROM         dbo.CURR_RATES INNER JOIN
                      ORAIBLIV..DATAHOUSE.CURR_RATES AS CURR_RATES_1 ON dbo.CURR_RATES.CURR1 = CURR_RATES_1.CURR1 AND 
                      dbo.CURR_RATES.CURR2 = CURR_RATES_1.CURR2

go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'curr_rates_IBANKLIV'
go

