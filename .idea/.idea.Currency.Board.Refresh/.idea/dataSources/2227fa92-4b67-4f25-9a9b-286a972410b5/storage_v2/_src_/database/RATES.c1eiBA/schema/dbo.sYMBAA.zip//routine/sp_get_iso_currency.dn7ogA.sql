create PROCEDURE [dbo].[sp_get_iso_currency]
@curr	varchar(4)

AS
BEGIN

select ISO_CODE from CURRENCY_ISO_VALUES where CURRENCY is not null and CURRENCY=@curr
END
go

