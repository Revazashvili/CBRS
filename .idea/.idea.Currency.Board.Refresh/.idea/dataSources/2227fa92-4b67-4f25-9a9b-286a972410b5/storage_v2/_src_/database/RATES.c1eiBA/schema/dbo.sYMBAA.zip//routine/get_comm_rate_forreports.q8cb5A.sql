CREATE FUNCTION [dbo].[get_comm_rate_forreports]
(@cur1 varchar(4),@cur2 varchar(4),@date date,@fx_cat int) 
RETURNS numeric(10,4)
AS
BEGIN
declare @rate numeric(10,4)
declare @ratenew numeric(10,6)
declare @rate1 numeric(10,4)
declare @rate2 numeric(10,4)
declare @scale int
declare @dir int
/*
select top 1 @rate=(case @fx_cat when 1 then RATE_BY1 when 2 then RATE_BY2 when 3 then RATE_BY3 when 4 then RATE_BY4 when 5 then RATE_BY5 end)/scale from dbo.CURR_RATES where curr1=@cur1 and curr2=@cur2 and DATE_VALUE<=dateadd(day,1,convert(date,convert(varchar(10),@date,101))) order by DATE_VALUE desc

if @rate is null
select top 1 @rate=(case @fx_cat when 1 then RATE_SELL1 when 2 then RATE_SELL2 when 3 then RATE_SELL3 when 4 then RATE_SELL4 when 5 then RATE_SELL5 end)/scale from dbo.CURR_RATES where curr1=@cur2 and curr2=@cur1 and DATE_VALUE<=dateadd(day,1,convert(date,convert(varchar(10),@date,101))) order by DATE_VALUE desc

*/
if @rate is null
if @cur1=@cur2 
set @rate=1
else
begin
  if @cur1='GEL' 
    set @rate1=1
  else
    select top 1 @rate1=(case @fx_cat when 1 then RATE_BY1 when 2 then RATE_BY2 when 3 then RATE_BY3 when 4 then RATE_BY4 when 5 then RATE_BY5 end)/scale from dbo.CURR_RATES (nolock) where curr1=@cur1 and curr2='GEL' and DATE_VALUE<=dateadd(day,1,convert(date,convert(varchar(10),@date,101))) order by DATE_VALUE desc
    
  if @cur2='GEL' 
    set @rate2=1
  else
    select top 1 @rate2=(case @fx_cat when 1 then RATE_SELL1 when 2 then RATE_SELL2 when 3 then RATE_SELL3 when 4 then RATE_SELL4 when 5 then RATE_SELL5 end)/scale from dbo.CURR_RATES (nolock) where curr1=@cur2 and curr2='GEL' and DATE_VALUE<=dateadd(day,1,convert(date,convert(varchar(10),@date,101))) order by DATE_VALUE desc
    
  set @rate=@rate1/@rate2

    if @cur1='GEL'
    set @ratenew=@rate1/@rate2
    set @rate=convert(numeric(10,6),(1/@ratenew))
    if @cur2='GEL' 
    set @rate=@rate1
    ELSE
   
            
            select top 1 @rate=convert(numeric(10,4),RATE_sell3) from CURR_RATES
           where CURR1=@cur1 and CURR2=@cur2 and type=1 and date_value<=getdate() order by date_value desc
     
    
    
	       
    
    
    
    




END

 
 RETURN @rate

END
go

