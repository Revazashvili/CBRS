CREATE procedure [dbo].[sync_rati_accounts]
	
AS
BEGIN
  SET NOCOUNT ON;
  CREATE TABLE #rest_26(
	[MFO] [varchar](15) NOT NULL,
	[account] [varchar](20) NOT NULL,
	[CURR] [varchar](3) NOT NULL,
	[rest] [money] NULL,
	[bal] [varchar](10) NULL,
	[nameaccount] [nvarchar](250) NULL,
	[sc] [int] NULL,
	[acc_id] numeric(10),
 CONSTRAINT [PK_rest_261a] PRIMARY KEY CLUSTERED 
(
	[MFO] ASC,
	[account] ASC,
	[CURR] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
  
  insert into #rest_26
  exec('select a.MFO, a.account, a.currency, a.rest,a.balance,a.NAME_ACCOUNT,a.DEPART,a.account_id
	from bank.acc_rests a
 where (a.BALANCE in (''2601'',
											''2611'',
											''6604'',
											''8604'',
											''6621'',
											''8621'',
											''4831'',
											''4841'',
											''2831'',
											''2841'',
											''3533'',
											''3523'',
											''3503'') or a.BALANCE like ''10__'' or a.BALANCE like ''15__'' or a.BALANCE like ''17__'' or a.BALANCE like ''14__'')
	 and (a.final_date>=trunc(sysdate)-30 or a.rest!=0)
	 and a.status = 1') at lbank
	 
--select * from #rest_26	 
declare @MFO varchar(10)
declare @account varchar(25)
declare @currency varchar(25)
declare @rest numeric(18,2)
declare @balance varchar(5)
declare @NAME_ACCOUNT nvarchar(250)
declare @DEPART int
declare @acc_id numeric(10)

declare @rp_date date
declare @ss varchar(1000)
declare @ss2 varchar(2)

declare curs cursor for select MFO,account,CURR,rest,bal,nameaccount,sc,acc_id from #rest_26
open curs
fetch next from curs into @MFO,@account,@currency,@rest,@balance,@NAME_ACCOUNT,@DEPART,@acc_id
while @@FETCH_STATUS=0
begin
  set @rp_date=cast( GETDATE() as date)
  if not exists(select 1 from rest_26 where mfo=@mfo and account=@account and curr=@currency and date_value=@rp_date)
         insert into rest_26(MFO, account, CURR, rest, date_value,bal,nameaccount,sc,change_date) values(@MFO,@account,@currency,@rest,@rp_date,@balance,@NAME_ACCOUNT,@DEPART,GETDATE())
          else update rest_26 set rest=@rest,change_date=GETDATE() where mfo=@mfo and account=@account and curr=@currency and date_value=@rp_date
  
  set @rp_date=DATEADD(day,-30,@rp_date)
  while @rp_date<cast( GETDATE() as date)
  begin
    set @rest=-17
    --set @ss='begin select LBINFO.GETREST(p_account_id => '+CONVERT(varchar(10),@acc_id)+',p_currency   => '''+@currency+''',p_date=> to_date('''+convert(varchar(10),@rp_date,103)+''', ''dd/mm/yyyy'')),''1'' into ?,? from dual; end;';
	set    @ss='begin select LBINFO.GETREST('+CONVERT(varchar(10),@acc_id)+','''+@currency+''',to_date('''+convert(varchar(10),@rp_date,103)+''', ''dd/mm/yyyy'')),''1'' into ?,? from dual; end;';
    SET @rest =NULL
	SET @ss2 =null
	EXEC (@ss,@rest output,@ss2 output) at LBREP
    if not exists(select 1 from rest_26 where mfo=@mfo and account=@account and curr=@currency and date_value=@rp_date)
         insert into rest_26(MFO, account, CURR, rest, date_value,bal,nameaccount,sc,change_date) values(@MFO,@account,@currency,@rest,@rp_date,@balance,@NAME_ACCOUNT,@DEPART,GETDATE())
          else update rest_26 set rest=@rest,change_date=GETDATE() where mfo=@mfo and account=@account and curr=@currency and date_value=@rp_date
 
    set @rp_date=DATEADD(day,1,@rp_date);
  end
  
  fetch next from curs into @MFO,@account,@currency,@rest,@balance,@NAME_ACCOUNT,@DEPART,@acc_id
end

deallocate curs

drop table #rest_26

END

go

