



CREATE VIEW [dbo].[VwMtServiceCenters]
AS
    select sp.sc_samcifr Code,
		   sp.MFO,
		   sp.SC,
		   sp.[Name],
		   sp.is_active ScIsAvtive,
		   sp.FXcategory,
		   s.ID,
		   s.[ScCategory],
		   s.IsActive,
		   s.[LastUpdateUser],
		   s.[LastUpdateTime]
      from [CORP_PROFILE].[dbo].SC_PAR sp
 left join [dbo].[MTRateServiceCenters] s
        on s.mfo = sp.MFO
       and s.sc  = sp.SC


go

grant insert, select, update on VwMtServiceCenters to [LB\TreasureRole]
go

