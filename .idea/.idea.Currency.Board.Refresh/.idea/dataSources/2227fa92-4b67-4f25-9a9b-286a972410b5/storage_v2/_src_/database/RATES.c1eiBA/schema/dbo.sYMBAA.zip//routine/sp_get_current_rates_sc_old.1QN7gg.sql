CREATE PROCEDURE [dbo].[sp_get_current_rates_sc_old]
@mfo varchar(10),
@sc int,
@cur1 varchar(3),
@cur2 varchar(3),
@type int,
@dat datetime
AS
BEGIN
	SET NOCOUNT ON;
	declare @sc_id int
	declare @fxcat int
	declare @dir int
	declare @cur3 varchar(3)
	declare @nbg_rat1 numeric(10,4)
	declare @nbg_rat2 numeric(10,4)
	declare @scale1 int
	declare @scale2 int
	set @dat=@dat+1
	select top 1 @nbg_rat1=rate,@scale1=scale from dbo.NBG_RATE where CURR=@cur1 and date_value<@dat order by date_value desc
	select top 1 @nbg_rat2=rate,@scale2=scale from dbo.NBG_RATE where CURR=@cur2 and date_value<@dat order by date_value desc
  if @nbg_rat1 is null set @nbg_rat1=1
  if @nbg_rat2 is null set @nbg_rat2=1
  if @scale1 is null set @scale1=1
  if @scale2 is null set @scale2=1
  
	if @cur1='GEL' begin
	                 set @cur3=@cur2
	                 set @cur2=@cur1
	                 set @cur1=@cur3
	                 set @dir=-1
	               end
	else 
    if @cur2='GEL' set @dir=1
	  else               
      if @cur1!='GEL' and @cur2!='GEL'
      begin
        if exists(select CURR1 from dbo.cross_currencies where CURR1=@cur1 and CURR2=@cur2)
            set @dir=1
          else 
            if exists(select CURR1 from dbo.cross_currencies where CURR1=@cur2 and CURR2=@cur1)
            begin
              set @dir=-1
              set @cur3=@cur2
                set @cur2=@cur1
              set @cur1=@cur3
            end;
            else set @dir=0
      end
	
	select @sc_id=Id,@fxcat=FXcategory from corp_profile.dbo.sc_par where MFO=@mfo and SC=@sc
  if @dir=1
	select top 1 
	       case @fxcat when 1 then convert(numeric(10,4),RATE_BY1)
	                   when 2 then convert(numeric(10,4),RATE_BY2)
	                   when 3 then convert(numeric(10,4),RATE_BY3)
	                   when 4 then convert(numeric(10,4),RATE_BY4)
	                   when 5 then convert(numeric(10,4),RATE_BY5)
	                end as rate ,
	       (CONVERT(varchar(20),date_value,103)+' '+CONVERT(varchar(20),date_value,108)) AS date_value1,curr1,curr2,@nbg_rat1 as RATE_NBG1,
	       @nbg_rat2 as RATE_NBG2,@dir as direction,scale,@scale1 as nbg_sc1,@scale2 as nbg_sc2,CORP_PROFILE.dbo.sf_get_sc_account(@sc_id,2,@cur1) as ovp1,CORP_PROFILE.dbo.sf_get_sc_account(@sc_id,2,@cur2) as ovp2 from CURR_RATES 
	       where CURR1=@CuR1 and CURR2=@cur2 and type=@type and date_value<=@dat order by date_value desc
	else
	  select top 1
	       case @fxcat when 1 then convert(numeric(10,4),RATE_sell1)
	                   when 2 then convert(numeric(10,4),RATE_sell2)
	                   when 3 then convert(numeric(10,4),RATE_sell3)
	                   when 4 then convert(numeric(10,4),RATE_sell4)
	                   when 5 then convert(numeric(10,4),RATE_sell5)
	                   end as rate ,
	       CONVERT(varchar(20),date_value,103)+' '+CONVERT(varchar(20) ,date_value,108) AS date_value1,curr1,curr2,@nbg_rat1 as RATE_NBG1,
	       @nbg_rat2 as RATE_NBG2,@dir as direction,scale,@scale1 as nbg_sc1,@scale2 as nbg_sc2,CORP_PROFILE.dbo.sf_get_sc_account(@sc_id,2,@cur1) as ovp1,CORP_PROFILE.dbo.sf_get_sc_account(@sc_id,2,@cur2) as ovp2 from CURR_RATES 
	       where CURR1=@CuR1 and CURR2=@cur2 and type=@type and date_value<=@dat order by date_value desc
	       
END
go

