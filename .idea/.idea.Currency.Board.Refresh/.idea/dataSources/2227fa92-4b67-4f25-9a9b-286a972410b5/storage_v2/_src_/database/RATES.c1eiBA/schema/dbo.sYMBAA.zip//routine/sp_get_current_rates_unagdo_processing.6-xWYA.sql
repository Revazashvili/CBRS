create PROCEDURE [dbo].[sp_get_current_rates_unagdo_processing]
AS
BEGIN
	SET NOCOUNT ON;
	declare @discount money
	select @discount=back_rate from dbo.processing_margin where id=1
	
	declare @discount_online money
	select @discount_online=online_rate from dbo.processing_margin where id=1

	
CREATE TABLE dbo.##CURR_RATES(
	CURR1 char(3) NULL,
	CURR2 char(3) NULL,
  --VAL_NAME nvarchar(50) NULL,
  scale int null,
	DATE_VALUE datetime NULL,
	RATE_BY5 money NULL,
	RATE_BY4 money NULL,
	RATE_BY3 money NULL,
	RATE_BY2 money NULL,
	RATE_BY1 money NULL,
	rate_market money NULL,
	RATE_SELL1 money NULL,
	RATE_SELL2 money NULL,
	RATE_SELL3 money NULL,
	RATE_SELL4 money NULL,
	RATE_SELL5 money NULL,
	RATE_NBG money NULL,
	priority int,
	RATEBY_ONLINE money,
	RATESELL_ONLINE money)
	
	insert into ##CURR_RATES(CURR1,CURR2,scale,priority) select CURR, 'GEL', scale,priority from dbo.CURRENCY  where status in (2,3) and processing=1
	
	update ##CURR_RATES set RATE_BY1=(select top 1 rate_by1 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2='GEL' and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_BY2=(select top 1 rate_by2 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2='GEL' and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_BY3=(select top 1 rate_by3 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2='GEL' and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATEBY_ONLINE=RATE_BY3-RATE_BY3*@discount_online/100
	update ##CURR_RATES set RATE_BY3=RATE_BY3-RATE_BY3*@discount/100
	update ##CURR_RATES set RATE_BY4=(select top 1 rate_by4 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2='GEL' and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_BY5=(select top 1 rate_by5 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2='GEL' and type=2 and date_value<=getdate() order by date_value desc)
	
	
	
	update ##CURR_RATES set RATE_sell1=(select top 1 rate_sell1 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2='GEL' and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_sell2=(select top 1 rate_sell2 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2='GEL' and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_sell3=(select top 1 rate_sell3 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2='GEL' and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATESELL_ONLINE=RATE_sell3+RATE_sell3*@discount_online/100
	update ##CURR_RATES set RATE_sell3=RATE_sell3+RATE_sell3*@discount/100
	update ##CURR_RATES set RATE_sell4=(select top 1 rate_sell4 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2='GEL' and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set RATE_sell5=(select top 1 rate_sell5 from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2='GEL' and type=2 and date_value<=getdate() order by date_value desc)
	
	
	update ##CURR_RATES set rate_market=(select top 1 rate_market from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2='GEL' and type=2 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set rate_NBG=(select top 1 rate from dbo.NBG_RATE where CURR=##CURR_RATES.CURR1 and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set rate_NBG=1 where rate_NBG is null
  update ##CURR_RATES set date_value=(select top 1 date_value from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2='GEL' and type=2 and date_value<=getdate() order by date_value desc)	
    
	SELECT * from ##CURR_RATES order by priority
	drop table ##CURR_RATES
END
go

