CREATE PROCEDURE [dbo].[yukon_convertation_sync]
AS
declare @mfo varchar(10)
declare @que varchar(512)
declare @dat date

set @dat=DATEADD(DAY, -10, GETDATE());
return;
/* Commented after drop YUKON 2014-jan-15
    INSERT OPENQUERY (YUKON, 'select ID, MFO, sc, date_carry, oper, shem, shem_val, gas, gas_val, appkey, rate, rate_nbg, gv, sax, pirn, sabn, ert, rate_nbg2, status, oper_name, TYPE from datahouse.convertaciebi')
             select ID, MFO, sc, date_carry, oper, shem, shem_val, gas, gas_val, appkey, rate, rate_nbg, gv, sax, pirn, sabn, ert, rate_nbg2, status, oper_name, TYPE 
             from [RATES].dbo.convertaciebi
             where date_carry>=cast(getdate()-1 as date) and date_carry<cast(getdate() as date) --added by Gela (01-Apr-2011)
print('finish')
print(@mfo)
print(@dat)

INSERT OPENQUERY (YUKON,'select "type", curr1, curr2, date_value, "scale", rate_by5, rate_by4, rate_by3, rate_by2, rate_by1, "rate_market", rate_sell1, rate_sell2, rate_sell3, rate_sell4, rate_sell5, rate_nbg,ent_date,"cont_id" from datahouse.curr_rates')
    SELECT[type],[CURR1],[CURR2],[DATE_VALUE],[scale],[RATE_BY5],[RATE_BY4],[RATE_BY3],[RATE_BY2],[RATE_BY1],[rate_market],[RATE_SELL1],[RATE_SELL2],[RATE_SELL3],[RATE_SELL4],[RATE_SELL5],[RATE_NBG],[ENT_DATE],[cont_id]
  FROM [RATES].[dbo].[CURR_RATES]
     where [date_value]>=cast(getdate()-1 as date)  

INSERT OPENQUERY (YUKON,'select curr,date_value,scale,rate,id from datahouse.nbg_rate')
    SELECT [CURR],[date_value],[scale],[rate],[id]
  FROM [RATES].[dbo].[NBG_RATE]
     where [date_value]>=cast(getdate()-1 as date)  
*/         
   
/*  
  INSERT OPENQUERY (YUKON,'select CURR,date_value,scale,rate,id from datahouse.nbg_rate')
    SELECT [CURR],[date_value],[scale],[rate],[id]
     FROM [RATES].[dbo].[NBG_RATE]
     where [date_value]>=cast(getdate()-1 as date)
     
     
 INSERT OPENQUERY (YUKON,'select "type", curr1, curr2, date_value, "scale", rate_by5, rate_by4, rate_by3, rate_by2, rate_by1, "rate_market", rate_sell1, rate_sell2, rate_sell3, rate_sell4, rate_sell5, rate_nbg,ent_date,"cont_id" from datahouse.curr_rates')
    SELECT[type],[CURR1],[CURR2],[DATE_VALUE],[scale],[RATE_BY5],[RATE_BY4],[RATE_BY3],[RATE_BY2],[RATE_BY1],[rate_market],[RATE_SELL1],[RATE_SELL2],[RATE_SELL3],[RATE_SELL4],[RATE_SELL5],[RATE_NBG],[ENT_DATE],[cont_id]
  FROM [RATES].[dbo].[CURR_RATES]
     where [date_value]>=cast(getdate()-1 as date)    

*/
go

