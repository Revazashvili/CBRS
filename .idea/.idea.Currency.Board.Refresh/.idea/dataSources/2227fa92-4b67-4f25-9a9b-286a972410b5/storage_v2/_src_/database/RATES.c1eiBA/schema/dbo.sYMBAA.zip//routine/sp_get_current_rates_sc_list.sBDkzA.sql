CREATE PROCEDURE [dbo].[sp_get_current_rates_sc_list]
@mfo varchar(10),
@sc int,
@type int
AS
BEGIN
	sET NOCOUNT ON;
	declare @fxcat int
	set @fxcat=dbo.sp_get_fx_cat(@mfo,@sc)
	
  CREATE TABLE dbo.##CURR_RATES(
	CURR1 char(3) NULL,
	CURR2 char(3) NULL,
  --VAL_NAME nvarchar(50) NULL,
  scale int null,
	DATE_VALUE datetime NULL,
	RATE_BY money NULL,
	rate_market money NULL,
	RATE_SELL money NULL,
	RATE_NBG money NULL,
	priority int)
	
	insert into ##CURR_RATES(CURR1,CURR2,scale,priority) select CURR, 'GEL', scale,priority from dbo.CURRENCY where dbo.sf_is_curr_perm(@mfo,@sc,CURR)=1
	insert into ##CURR_RATES(CURR1,CURR2,scale,priority) select CURR1, CURR2, scale,100 from dbo.cross_currencies where dbo.sf_is_curr_perm(@mfo,@sc,CURR1)=1 and dbo.sf_is_curr_perm(@mfo,@sc,CURR2)=1
	
	update ##CURR_RATES set RATE_BY=(select top 1 case @fxcat when 1 then rate_by1 
	                                                          when 2 then rate_by2 
	                                                          when 3 then rate_by3 
	                                                          when 4 then rate_by4 
	                                                          when 5 then rate_by5 
	                                              end as RATE_BY from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=@type and date_value<=getdate() order by date_value desc)                                            
	update ##CURR_RATES set RATE_sell=(select top 1 case @fxcat when 1 then rate_sell1
	                                                            when 2 then rate_sell2
	                                                            when 3 then rate_sell3
	                                                            when 4 then rate_sell4
	                                                            when 5 then rate_sell5
	                                                end as RATE_sell from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=@type and date_value<=getdate() order by date_value desc)
	
	update ##CURR_RATES set rate_market=(select top 1 rate_market from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=@type and date_value<=getdate() order by date_value desc)
	update ##CURR_RATES set rate_NBG=(select top 1 rate from dbo.NBG_RATE where CURR=##CURR_RATES.CURR1 and date_value<=getdate() order by date_value desc) where CURR2='GEL'
	
	update ##CURR_RATES set rate_NBG=(select top 1 rate/scale from dbo.NBG_RATE where CURR=##CURR_RATES.CURR1 and date_value<=getdate() order by date_value desc)/
	(select top 1 rate/scale from dbo.NBG_RATE where CURR=##CURR_RATES.CURR2 and date_value<=getdate() order by date_value desc) where CURR2!='GEL'
	
	
	update ##CURR_RATES set rate_NBG=1 where rate_NBG is null
  update ##CURR_RATES set date_value=(select top 1 date_value from dbo.CURR_RATES where CURR1=##CURR_RATES.CURR1 and CURR2=##CURR_RATES.CURR2 and type=@type and date_value<=getdate() order by date_value desc)	
    
    delete from ##CURR_RATES where date_value<dateadd(day,-10,GETDATE())
    delete from ##CURR_RATES where RATE_BY is null
	SELECT CURR1,CURR2,scale,priority,RATE_BY,RATE_sell,RATE_NBG,convert(varchar(20),date_value,120) date_value from ##CURR_RATES order by priority
	drop table ##CURR_RATES
	       
END
go

