CREATE FUNCTION [dbo].[get_nbg_ratef](@curr1 varchar(3),@curr2 varchar(3),@date datetime) 
RETURNS float
AS
BEGIN
declare @rate float
declare @rate1 float
declare @rate2 float

declare @sc1 float
declare @sc2 float

  set @rate1=1
  set @rate2=1
  set @sc1=1
  set @sc2=1
  
  select top 1 @rate1=rate,@sc1=scale from  rates.dbo.NBG_RATE where  CURR=@curr1 and date_value<=@date order by date_value desc
  select top 1 @rate2=rate,@sc2=scale from  rates.dbo.NBG_RATE where  CURR=@curr2 and date_value<=@date order by date_value desc
  
  if @rate1=0 or @rate1 is null set @rate1=1
  if @rate2=0 or @rate2 is null set @rate2=1
  if @curr1='GEL' or @curr2='GEL'
    set @rate=@rate1/@rate2*(@sc2/@sc1)
  else
    set @rate=@rate1/@rate2*(@sc2/@sc1)
  
  set @rate=convert(numeric(10,4),@rate)
  RETURN @rate
END
-- select [dbo].[get_nbg_ratef]('EUR','GBP','08/10/2011')

go

