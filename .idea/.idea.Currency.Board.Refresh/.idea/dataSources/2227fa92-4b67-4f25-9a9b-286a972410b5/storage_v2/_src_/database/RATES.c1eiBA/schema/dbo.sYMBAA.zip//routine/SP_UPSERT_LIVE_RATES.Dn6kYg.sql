CREATE PROCEDURE [dbo].[SP_UPSERT_LIVE_RATES] /*sole purpose of this procedure is to store 'LIVE' rates in separate table*/
(
    @type INT,
    @CURR1 VARCHAR(4),
    @CURR2 VARCHAR(4),
    @DATE_VALUE DATETIME,
    @scale INT,
    @RATE_BY5 MONEY,
    @RATE_BY4 MONEY,
    @RATE_BY3 MONEY,
    @RATE_BY2 MONEY,
    @RATE_BY1 MONEY,
    @rate_market MONEY,
    @RATE_SELL1 MONEY,
    @RATE_SELL2 MONEY,
    @RATE_SELL3 MONEY,
    @RATE_SELL4 MONEY,
    @RATE_SELL5 MONEY,
    @RATE_NBG MONEY,
    @cont_id INT
)
AS
BEGIN
	IF (EXISTS
    (
        SELECT *
        FROM dbo.CURR_RATES_LIVE
        WHERE type = @type
              AND CURR1 = @CURR1
              AND CURR2 = @CURR2
			  AND DATE_VALUE > @DATE_VALUE
    )) RETURN;

    IF (EXISTS
    (
        SELECT *
        FROM dbo.CURR_RATES_LIVE
        WHERE type = @type
              AND CURR1 = @CURR1
              AND CURR2 = @CURR2
    )
       )
    BEGIN
        UPDATE dbo.CURR_RATES_LIVE
        SET [DATE_VALUE] = @DATE_VALUE,
            [scale] = @scale,
            [RATE_BY5] = @RATE_BY5,
            [RATE_BY4] = @RATE_BY4,
            [RATE_BY3] = @RATE_BY3,
            [RATE_BY2] = @RATE_BY2,
            [RATE_BY1] = @RATE_BY1,
            [rate_market] = @rate_market,
            [RATE_SELL1] = @RATE_SELL1,
            [RATE_SELL2] = @RATE_SELL2,
            [RATE_SELL3] = @RATE_SELL3,
            [RATE_SELL4] = @RATE_SELL4,
            [RATE_SELL5] = @RATE_SELL5,
            [RATE_NBG] = @RATE_NBG,
            [ENT_DATE] = GETDATE(),
            [cont_id] = @cont_id
        WHERE type = @type
              AND CURR1 = @CURR1
              AND CURR2 = @CURR2;
    END;
    ELSE
    BEGIN
        INSERT INTO dbo.CURR_RATES_LIVE
        (
            type,
            CURR1,
            CURR2,
            DATE_VALUE,
            scale,
            RATE_BY5,
            RATE_BY4,
            RATE_BY3,
            RATE_BY2,
            RATE_BY1,
            rate_market,
            RATE_SELL1,
            RATE_SELL2,
            RATE_SELL3,
            RATE_SELL4,
            RATE_SELL5,
            RATE_NBG,
            ENT_DATE,
            cont_id
        )
        VALUES
        (@type, @CURR1, @CURR2, @DATE_VALUE, @scale, @RATE_BY5, @RATE_BY4, @RATE_BY3, @RATE_BY2, @RATE_BY1,
         @rate_market, @RATE_SELL1, @RATE_SELL2, @RATE_SELL3, @RATE_SELL4, @RATE_SELL5, @RATE_NBG, GETDATE(), @cont_id);
    END;
END;
go

