CREATE FUNCTION [dbo].[GET_MOGEBA]
(
  @VAL0 NVARCHAR(15),
  @VAL1 NVARCHAR(15),
  @IN_Amm money,
  @out_amm money,
  @rat1 money,
  @rat1n money,
  @rat2n money,
  @ert integer,
  @ert2 integer  
)
RETURNS money
AS
BEGIN
declare @mog money

  if @val0=N'ლარი' or @VAL0='GEL'
       set @mog=@IN_Amm-@out_amm*@rat2n/@ert2
	  else
		if @val1=N'ლარი' or @VAL1='GEL'
		  set @mog=@in_amm*@rat1n/@ert-@out_amm
		else
		  --set @mog= @rat2n*@out_amm/@ert2-@rat1n*@IN_Amm/@ert
		  set @mog=@rat1n*@IN_Amm/@ert-@rat2n*@out_amm/@ert2
	RETURN @mog

END
go

