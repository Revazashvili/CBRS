CREATE PROCEDURE [dbo].[get_request_documents]
@mfo varchar(10),
@sc int,
@amount money
AS
BEGIN

declare @ans int
if exists(select ID from FX_request_documents F where coalesce(F.mfo,@mfo)=@mfo and coalesce(F.sc,@sc)=@sc and F.amount>=@amount)
	set @ans=0
else
	set @ans=1
	
	select @ans as need

	--SELECT @val1,@val2,@RATE_BY5,@RATE_BY4,@RATE_BY3,@RATE_BY2,@RATE_BY1,@rate_market,@RATE_SELL1,@RATE_SELL2,@RATE_SELL3,@RATE_SELL4,@RATE_SELL5
END
go

