CREATE PROCEDURE [dbo].[sp_get_current_rates_sc_list_min_max_Hist] --'220101999',99,2,'2016-04-20'
@mfo varchar(10),
@sc int,
@type int,
@dat datetime
AS
BEGIN
	sET NOCOUNT ON;
	declare @fxcat int
	set @fxcat=dbo.sp_get_fx_cat(@mfo,@sc)
	print(@fxcat)
  CREATE TABLE dbo.#CURR_RATES(
	CURR1 char(3) NULL,
	CURR2 char(3) NULL,
  --VAL_NAME nvarchar(50) NULL,
  scale int null,
	DATE_VALUE datetime NULL,
	RATE_BY_min money NULL,
	RATE_BY_max money NULL,
	rate_market money NULL,
	RATE_SELL_min money NULL,
	RATE_SELL_max money NULL,
	RATE_NBG money NULL,
	priority int)
	
	insert into #CURR_RATES(CURR1,CURR2,scale,priority,DATE_VALUE) select CURR, 'GEL', scale,priority,@dat from dbo.CURRENCY 
	--insert into #CURR_RATES(CURR1,CURR2,scale,priority) select CURR1, CURR2, scale,100 from dbo.cross_currencies
	
	update #CURR_RATES set RATE_BY_min=(select MIN( case @fxcat when 1 then rate_by1 
	                                                          when 2 then rate_by2 
	                                                          when 3 then rate_by3 
	                                                          when 4 then rate_by4 
	                                                          when 5 then rate_by5 
	                                              end) as RATE_BY from dbo.CURR_RATES 
	                                              where CURR1=#CURR_RATES.CURR1 and CURR2=#CURR_RATES.CURR2 and type=@type and date_value between @dat and @dat+1)                        
	update #CURR_RATES set RATE_SELL_min=(select MIN( case @fxcat when 1 then rate_sell1
	                                                            when 2 then rate_sell2
	                                                            when 3 then rate_sell3
	                                                            when 4 then rate_sell4
	                                                            when 5 then rate_sell5
	                                                end) as RATE_sell from dbo.CURR_RATES 
	                                                where CURR1=#CURR_RATES.CURR1 and CURR2=#CURR_RATES.CURR2 and type=@type and date_value between @dat and @dat+1)
	update #CURR_RATES set RATE_BY_max=(select max( case @fxcat when 1 then rate_by1 
	                                                          when 2 then rate_by2 
	                                                          when 3 then rate_by3 
	                                                          when 4 then rate_by4 
	                                                          when 5 then rate_by5 
	                                              end) as RATE_BY from dbo.CURR_RATES 
	                                              where CURR1=#CURR_RATES.CURR1 and CURR2=#CURR_RATES.CURR2 and type=@type and date_value between @dat and @dat+1)
	update #CURR_RATES set RATE_SELL_max=(select max( case @fxcat when 1 then rate_sell1
	                                                            when 2 then rate_sell2
	                                                            when 3 then rate_sell3
	                                                            when 4 then rate_sell4
	                                                            when 5 then rate_sell5
	                                                end) as RATE_sell from dbo.CURR_RATES 
	                                                where CURR1=#CURR_RATES.CURR1 and CURR2=#CURR_RATES.CURR2 and type=@type and date_value between @dat and @dat+1)
    update #CURR_RATES set RATE_BY_min=(select top 1 case @fxcat when 1 then rate_by1 
                                      when 2 then rate_by2 
                                      when 3 then rate_by3 
                                      when 4 then rate_by4 
                                      when 5 then rate_by5 
                          end as RATE_BY from dbo.CURR_RATES where CURR1=#CURR_RATES.CURR1 and CURR2=#CURR_RATES.CURR2 and type=@type and date_value<=@dat order by date_value desc)
           where RATE_BY_min is null
    update #CURR_RATES set RATE_BY_max=(select top 1 case @fxcat when 1 then rate_by1 
                                      when 2 then rate_by2 
                                      when 3 then rate_by3 
                                      when 4 then rate_by4 
                                      when 5 then rate_by5 
                          end as RATE_BY from dbo.CURR_RATES where CURR1=#CURR_RATES.CURR1 and CURR2=#CURR_RATES.CURR2 and type=@type and date_value<=@dat order by date_value desc)
           where RATE_BY_max is null
    update #CURR_RATES set RATE_SELL_min=(select top 1 case @fxcat when 1 then rate_sell1
	                                                            when 2 then rate_sell2
	                                                            when 3 then rate_sell3
	                                                            when 4 then rate_sell4
	                                                            when 5 then rate_sell5
                          end as RATE_BY from dbo.CURR_RATES where CURR1=#CURR_RATES.CURR1 and CURR2=#CURR_RATES.CURR2 and type=@type and date_value<=@dat order by date_value desc)
           where RATE_SELL_min is null	 
    update #CURR_RATES set RATE_SELL_max=(select top 1 case @fxcat when 1 then rate_sell1
	                                                            when 2 then rate_sell2
	                                                            when 3 then rate_sell3
	                                                            when 4 then rate_sell4
	                                                            when 5 then rate_sell5
                          end as RATE_BY from dbo.CURR_RATES where CURR1=#CURR_RATES.CURR1 and CURR2=#CURR_RATES.CURR2 and type=@type and date_value<=@dat order by date_value desc)
           where RATE_SELL_max is null	                                               
	update #CURR_RATES set rate_market=(select top 1 rate_market from dbo.CURR_RATES where CURR1=#CURR_RATES.CURR1 and CURR2='GEL' and type=@type and date_value<=@dat order by date_value desc)
	update #CURR_RATES set rate_NBG=(select top 1 rate from dbo.NBG_RATE where CURR=#CURR_RATES.CURR1 and date_value<=@dat order by date_value desc)
	update #CURR_RATES set rate_NBG=1 where rate_NBG is null
   -- update #CURR_RATES set date_value=(select top 1 date_value from dbo.CURR_RATES where CURR1=#CURR_RATES.CURR1 and CURR2='GEL' and type=@type and date_value<=@dat order by date_value desc)	
    
	SELECT * from #CURR_RATES where (RATE_BY_min is not null) and (RATE_SELL_min is not null) order by priority
	drop table #CURR_RATES
	       
END
go

grant execute on sp_get_current_rates_sc_list_min_max_Hist to current_rates_user
go

