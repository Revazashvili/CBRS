-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[prc_get_mt_current_rate_cashless] --'220101480',2,'RUB','EUR'
	@mfo       char(9),
	@sc	       smallint,
	@currency1 char(3),
	@currency2 char(3)
AS
BEGIN
	SET NOCOUNT ON;
	declare @pairCode	  as char(7)
	declare @mtCategory   as tinyint
	declare @mtRateStatus as bit
	declare @mtRateID	  as int
	declare @currentDate  as datetime
	declare @buyRate	  as decimal(18,4)
	declare @sellRate	  as decimal(18,4)
	declare @result as table (
							   rate        numeric(18,4),
							   date_value1 varchar(64),
							   curr1	   char(3),
							   curr2	   char(3),
							   RATE_NBG1   numeric(18,4),
							   RATE_NBG2   numeric(18,4),
							   direction   smallint,
							   scale	   int,
							   nbg_sc1	   int,
							   nbg_sc2	   int,
							   ovp1	       varchar(32),
							   ovp2        varchar(32)
							 );


	set @currentDate = getdate()
	set @pairCode	 = @currency1 + '/' + @currency2;

	
	insert 
	  into @result (rate,date_value1,curr1,curr2,RATE_NBG1,RATE_NBG2,direction,scale,nbg_sc1,nbg_sc2,ovp1,ovp2)
	  execute [dbo].[sp_get_current_rates_sc] @mfo, @sc, @currency1, @currency2, 2, @currentDate
	

    select @mtRateStatus = m.ModuleStatus   from MTRateModule m
    select @mtCategory   = s.ScCategory     from dbo.MTRateServiceCenters s where s.MFO = @mfo and s.SC = @sc and s.IsActive = 1;
	select @mtRateID     = mp.CurrentRateID from dbo.MTRatePairs mp	join dbo.MTRateValues mv on mv.ID=mp.CurrentRateID and mv.[Status]=1 
	where (mp.PairCode1 = @pairCode or mp.PairCode2 = @pairCode) and mp.[Status] = 1;

	if ISNULL(@mtCategory,0) > 0 and ISNULL(@mtRateStatus,0) = 1 and ISNULL(@mtRateID,0) > 0
	begin
	  select @buyRate  = case @mtCategory when 1 then mv.BuyRate1  else mv.BuyRate2  end,
			 @sellRate = case @mtCategory when 1 then mv.SellRate1 else mv.SellRate1 end
	    from dbo.MTRateValues mv 
	   where mv.ID = @mtRateID 
	     and mv.[Status]=1
	  
	  update @result set rate = @buyRate  where direction  = 1;
	  update @result set rate = @sellRate where direction != 1;
	end;
	select * from @result
END
go

