CREATE PROCEDURE [dbo].[get_permissible_currencyes]
@cur1 varchar(5),
@cur2 varchar(5),
@mfo varchar(10),
@sc int
AS
declare @ans int

if @cur1='GEL' or @cur2='GEL'
	if exists(select scale from CURRENCY c where (c.CURR=@cur1 or c.CURR=@cur2 ) and status in (1,3))
		set @ans=1
	else
		set @ans=0
else
if (exists(select scale from cross_currencies p where ((p.CURR1=@cur1 and p.CURR2=@cur2)OR(p.CURR1=@cur2 and p.CURR2=@cur1)) and status in (1,3)))
	set @ans=1
else
	set @ans=0


select @ans as status
	--SELECT @val1,@val2,@RATE_BY5,@RATE_BY4,@RATE_BY3,@RATE_BY2,@RATE_BY1,@rate_market,@RATE_SELL1,@RATE_SELL2,@RATE_SELL3,@RATE_SELL4,@RATE_SELL5

go

