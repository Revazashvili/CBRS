-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[LBREP_sync_convertaciebi]
	
AS

	-- გადაყვანილია რეპლიკაციაზე
/*
BEGIN

	insert into LBREP..LBINFO.CONVERTACIEBI
		(id,  mfo,  sc,   date_carry,  oper,  shem,  shem_val,  gas,  gas_val,  appkey,  rate,  rate_nbg,  gv,  sax,  pirn,  sabn,  ert,  rate_nbg2,  status,  oper_name,  type,  ert2,  spec_kurs,CITIZENSHIP,ADDRESS)
SELECT  [ID],[MFO],[sc], [date_carry],[oper],[shem],[shem_val],[gas],[gas_val],[appkey],[rate],[rate_nbg],[gv],[sax],[pirn],[sabn],[ert],[rate_nbg2],[status],[oper_name],[TYPE],[ert2],[spec_kurs],CITIZENSHIP,ADDRESS
  FROM [RATES].[dbo].[convertaciebi]
  where ID > (select max(t.id) from LBREP..LBINFO.CONVERTACIEBI t)


END
*/
go

