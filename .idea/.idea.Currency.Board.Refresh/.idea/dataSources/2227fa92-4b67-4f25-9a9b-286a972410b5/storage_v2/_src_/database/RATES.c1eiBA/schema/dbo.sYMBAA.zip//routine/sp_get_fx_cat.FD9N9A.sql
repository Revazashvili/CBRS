CREATE FUNCTION [dbo].[sp_get_fx_cat](@mfo varchar(10),@sc varchar(10))
RETURNS int
AS
BEGIN
  declare @fxcat int
	SELECT top 1 @fxcat=FXcategory from CORP_PROFILE.dbo.SC_PAR where MFO=@mfo and SC=@sc
	RETURN @fxcat
END
go

