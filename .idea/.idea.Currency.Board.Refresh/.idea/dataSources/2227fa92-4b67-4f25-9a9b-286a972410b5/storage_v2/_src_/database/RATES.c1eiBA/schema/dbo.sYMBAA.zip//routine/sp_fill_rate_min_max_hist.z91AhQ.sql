
CREATE PROCEDURE [dbo].[sp_fill_rate_min_max_hist]
AS
BEGIN
	SET NOCOUNT ON;
declare @mfo varchar(10),
@sc int,
@type int,
@dat datetime,
@fxcat int

set @mfo='220101999'
set @sc=99
set @type=2
set @fxcat=dbo.sp_get_fx_cat(@mfo,@sc)

declare @start_date datetime,@end_date datetime


select @start_date=MAX(DATE_VALUE) from RATE_HIST_MIN_MAX(nolock) where  FXcategory=@fxcat and type=@type
set @start_date=@start_date+1
set @end_date=CONVERT(date, getdate())
set @end_date=@end_date-1
set @dat=@start_date

while(@dat<=@end_date)

begin
insert into RATE_HIST_MIN_MAX(DATE_VALUE, CURR1, CURR2, scale,  FXcategory, type)
select @dat,CURR, 'GEL', scale,@fxcat,@type from dbo.CURRENCY 
update RATE_HIST_MIN_MAX set RATE_BUY_min=(select MIN( case @fxcat when 1 then rate_by1 
	                                                          when 2 then rate_by2 
	                                                          when 3 then rate_by3 
	                                                          when 4 then rate_by4 
	                                                          when 5 then rate_by5 
	                                              end) as RATE_BY from dbo.CURR_RATES 
	                                              where CURR1=RATE_HIST_MIN_MAX.CURR1 and CURR2=RATE_HIST_MIN_MAX.CURR2  and type=@type and date_value between @dat and @dat+1) 
	                                              
	                                             where  RATE_HIST_MIN_MAX.DATE_VALUE=@dat and type=@type and FXcategory=@fxcat 
	update RATE_HIST_MIN_MAX set RATE_SELL_min=(select MIN( case @fxcat when 1 then rate_sell1
	                                                            when 2 then rate_sell2
	                                                            when 3 then rate_sell3
	                                                            when 4 then rate_sell4
	                                                            when 5 then rate_sell5
	                                                end) as RATE_sell from dbo.CURR_RATES 
	                                                where CURR1=RATE_HIST_MIN_MAX.CURR1 and CURR2=RATE_HIST_MIN_MAX.CURR2  and type=@type and date_value between @dat and @dat+1)
	                                                 where  RATE_HIST_MIN_MAX.DATE_VALUE=@dat and type=@type and FXcategory=@fxcat 
	update RATE_HIST_MIN_MAX set RATE_BUY_max=(select max( case @fxcat when 1 then rate_by1 
	                                                          when 2 then rate_by2 
	                                                          when 3 then rate_by3 
	                                                          when 4 then rate_by4 
	                                                          when 5 then rate_by5 
	                                              end) as RATE_BY from dbo.CURR_RATES 
	                                              where CURR1=RATE_HIST_MIN_MAX.CURR1 and CURR2=RATE_HIST_MIN_MAX.CURR2  and type=@type and date_value between @dat and @dat+1 )
	                                               where  RATE_HIST_MIN_MAX.DATE_VALUE=@dat and type=@type and FXcategory=@fxcat 
	update RATE_HIST_MIN_MAX set RATE_SELL_max=(select max( case @fxcat when 1 then rate_sell1
	                                                            when 2 then rate_sell2
	                                                            when 3 then rate_sell3
	                                                            when 4 then rate_sell4
	                                                            when 5 then rate_sell5
	                                                end) as RATE_sell from dbo.CURR_RATES 
	                                                where CURR1=RATE_HIST_MIN_MAX.CURR1 and CURR2=RATE_HIST_MIN_MAX.CURR2  and type=@type and date_value between @dat and @dat+1)
	                                                where  RATE_HIST_MIN_MAX.DATE_VALUE=@dat and type=@type and FXcategory=@fxcat 
    update RATE_HIST_MIN_MAX set RATE_BuY_min=(select top 1 case @fxcat when 1 then rate_by1 
                                      when 2 then rate_by2 
                                      when 3 then rate_by3 
                                      when 4 then rate_by4 
                                      when 5 then rate_by5 
                          end as RATE_BY from dbo.CURR_RATES where CURR1=RATE_HIST_MIN_MAX.CURR1 and CURR2=RATE_HIST_MIN_MAX.CURR2 and type=@type and date_value<=@dat order by date_value desc)
           where RATE_BuY_min is null and RATE_HIST_MIN_MAX.DATE_VALUE=@dat and type=@type and FXcategory=@fxcat 
    update RATE_HIST_MIN_MAX set RATE_BuY_max=(select top 1 case @fxcat when 1 then rate_by1 
                                      when 2 then rate_by2 
                                      when 3 then rate_by3 
                                      when 4 then rate_by4 
                                      when 5 then rate_by5 
                          end as RATE_BY from dbo.CURR_RATES where CURR1=RATE_HIST_MIN_MAX.CURR1 and CURR2=RATE_HIST_MIN_MAX.CURR2 and type=@type and date_value<=@dat order by date_value desc)
           where RATE_BuY_max is null and RATE_HIST_MIN_MAX.DATE_VALUE=@dat and type=@type and FXcategory=@fxcat 
    update RATE_HIST_MIN_MAX set RATE_SELL_min=(select top 1 case @fxcat when 1 then rate_sell1
	                                                            when 2 then rate_sell2
	                                                            when 3 then rate_sell3
	                                                            when 4 then rate_sell4
	                                                            when 5 then rate_sell5
                          end as RATE_BY from dbo.CURR_RATES where CURR1=RATE_HIST_MIN_MAX.CURR1 and CURR2=RATE_HIST_MIN_MAX.CURR2 and type=@type and date_value<=@dat order by date_value desc)
           where RATE_SELL_min is null	 and RATE_HIST_MIN_MAX.DATE_VALUE=@dat and type=@type and FXcategory=@fxcat 
    update RATE_HIST_MIN_MAX set RATE_SELL_max=(select top 1 case @fxcat when 1 then rate_sell1
	                                                            when 2 then rate_sell2
	                                                            when 3 then rate_sell3
	                                                            when 4 then rate_sell4
	                                                            when 5 then rate_sell5
                          end as RATE_BY from dbo.CURR_RATES where CURR1=RATE_HIST_MIN_MAX.CURR1 and CURR2=RATE_HIST_MIN_MAX.CURR2 and type=@type and date_value<=@dat order by date_value desc)
           where RATE_SELL_max is null	 and RATE_HIST_MIN_MAX.DATE_VALUE=@dat and type=@type and FXcategory=@fxcat                                            
	update RATE_HIST_MIN_MAX set rate_NBG=(select top 1 rate from dbo.NBG_RATE where CURR=RATE_HIST_MIN_MAX.CURR1 and date_value<=@dat order by date_value desc)
	      where RATE_HIST_MIN_MAX.DATE_VALUE=@dat and type=@type and FXcategory=@fxcat   
	

set @dat=@dat+1
end
update RATE_HIST_MIN_MAX set rate_NBG=1 where rate_NBG is null
end
go

