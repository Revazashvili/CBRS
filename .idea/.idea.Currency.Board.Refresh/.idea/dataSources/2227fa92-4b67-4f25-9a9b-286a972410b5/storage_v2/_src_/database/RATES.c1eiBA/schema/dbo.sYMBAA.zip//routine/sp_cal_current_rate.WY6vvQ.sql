CREATE PROCEDURE sp_cal_current_rate
@rate_market money,
@val varchar(4)
AS
BEGIN
	SET NOCOUNT ON;
declare @RATE_BY5 money
declare @RATE_BY4 money
declare @RATE_BY3 money
declare @RATE_BY2 money
declare @RATE_BY1 money
declare @RATE_SELL1 money
declare @RATE_SELL2 money
declare @RATE_SELL3 money
declare @RATE_SELL4 money
declare @RATE_SELL5 money

  select @val as CURR,@rate_market-DIFF_BY5*@rate_market/100 as rate_by5,@rate_market-DIFF_BY4*@rate_market/100 as rate_by4,@rate_market-DIFF_BY3*@rate_market/100 as rate_by3,@rate_market-DIFF_BY2*@rate_market/100 as rate_by2,@rate_market-DIFF_BY1*@rate_market/100 as rate_by1,@rate_market as rate_market,
         @rate_market+DIFF_sell1*@rate_market/100 as rate_sell1,@rate_market+DIFF_sell2*@rate_market/100 as rate_sell2,@rate_market+DIFF_sell3*@rate_market/100 as rate_sell3,@rate_market+DIFF_sell4*@rate_market/100 as rate_sell4,@rate_market+DIFF_sell5*@rate_market/100 as rate_sell5
         from dbo.cat_diff where CURR=@val

	--SELECT @val1,@val2,@RATE_BY5,@RATE_BY4,@RATE_BY3,@RATE_BY2,@RATE_BY1,@rate_market,@RATE_SELL1,@RATE_SELL2,@RATE_SELL3,@RATE_SELL4,@RATE_SELL5
END
go

