--get_rate_table '09/16/2011',2
CREATE procedure [dbo].[get_rate_table](@datee date,@fx_cat int)
as
  set nocount on
  declare @tabn varchar(20)
  set @tabn ='##ctable'
  declare @i int
  declare @j int
  declare @cc int
  declare @ss varchar(2048)
  declare @ss1 varchar(2048)
  set @i=0;
  set @ss=''
  select @cc=COUNT(*) from [CURRENCY]
  set @ss='create table '+@tabn+'(currency varchar(5),scale int,priority int,'
  while @i<@cc
  begin
    set @ss=@ss+'cur'+convert(varchar(2),@i)+' numeric(10,4),'
    set @i=@i+1
  end
  set @ss=substring(@ss,1,LEN(@ss)-1)
  set @ss=@ss+')  ON [PRIMARY]'
  exec(@ss)
  
 /* set @ss='insert into '+@tabn+'(currency,scale,priority) values(''GEL'',1,0)'
  exec(@ss)*/
  
  set @ss='insert into '+@tabn+'(currency,scale,priority) select CURR,scale,priority from dbo.CURRENCY order by priority'
  exec(@ss)
  
  declare @CURR varchar(5)
  declare @CURR1 varchar(5)
  declare @scale int
  declare @priority int
  declare @priority1 int
  set @i=1;
  set @j=1;
  
  declare curs cursor for select CURR,scale,priority from 
                             (select CURR,scale,priority from dbo.CURRENCY
                             /*union
                             select 'GEL' as curr,1,0 as priority*/) t order by priority
  open curs
  fetch next from curs into @CURR,@scale,@priority
  while @@FETCH_STATUS=0
  begin
  
    set @i=0
    declare curs1 cursor for select * from 
                             (select CURR,priority from dbo.CURRENCY
                             /*union
                             select 'GEL' as curr,0 as priority*/) t order by priority
    open curs1
    fetch next from curs1 into @CURR1,@priority1
    while @@FETCH_STATUS=0
    begin 
      print(@curr)
      set @ss1='update '+@tabn+' set cur'+CONVERT(varchar(20),@i)+'='+CONVERT(varchar(20),dbo.get_comm_rate_table(@curr,@curr1,@datee,@fx_cat,2))+' where currency='''+@curr+''''
      exec(@ss1)
      set @i=@i+1
      fetch next from curs1 into @CURR1,@priority1
    end
    deallocate curs1
    fetch next from curs into @CURR,@scale,@priority
  end;
  deallocate curs
  
  
  
  set @ss='select * from ##ctable order by priority'
  exec(@ss)
  --declare @ss1 varchar(2048)
  set @ss1='drop table ##ctable'
  exec(@ss1)
go

grant execute on get_rate_table to rati
go

