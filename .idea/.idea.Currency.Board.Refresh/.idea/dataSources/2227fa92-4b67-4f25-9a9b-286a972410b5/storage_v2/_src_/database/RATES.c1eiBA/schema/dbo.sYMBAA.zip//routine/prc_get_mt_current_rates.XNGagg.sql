CREATE PROCEDURE [dbo].[prc_get_mt_current_rates]
	@mfo       char(9),
	@sc	      smallint
AS
BEGIN
	SET NOCOUNT ON;
	declare @index	       as int
	declare @pairCode	  as char(7)
	declare @mtCategory   as tinyint
	declare @mtRateStatus as bit
	declare @mtRateID	  as int
	declare @currentDate  as datetime
	declare @buyRate	  as decimal(18,4)
	declare @sellRate	  as decimal(18,4)

	declare @currencies as table ( 
							 code char(3) 
						    );
	
	declare @result as table (
						  rate        numeric(18,4),
						  date_value1 varchar(64),
						  curr1	    char(3),
						  curr2	    char(3),
						  RATE_NBG1   numeric(18,4),
						  RATE_NBG2   numeric(18,4),
						  direction   smallint,
						  scale	    int,
						  nbg_sc1	    int,
						  nbg_sc2	    int,
						  ovp1	    varchar(32),
						  ovp2        varchar(32),
						  PairCode    char(7)
						);


	set @currentDate = getdate()
	
	
	insert into @currencies (code)
	select case when x.[name]='RUR' then 'RUB' else x.[name] end from LBANK..MTTRANSFER.CURRENCY x;

	select @mtRateStatus = m.ModuleStatus from MTRateModule m
     select @mtCategory   = s.ScCategory   from dbo.MTRateServiceCenters s where s.MFO = @mfo and s.SC = @sc and s.IsActive = 1;

	declare currencyCursor cursor for select c1.code currency1,c2.code currency2 from @currencies c1 join @currencies c2 on c1.code!=c2.code;
	declare @currency1 char(3)
	declare @currency2 char(3)

	set @index = 0;
	open currencyCursor
	fetch next from currencyCursor into @currency1,@currency2
	while @@fetch_status=0
	begin
	  set @pairCode	 = @currency1 + '/' + @currency2;
	  insert 
	    into @result (rate,date_value1,curr1,curr2,RATE_NBG1,RATE_NBG2,direction,scale,nbg_sc1,nbg_sc2,ovp1,ovp2)
	 execute [dbo].[sp_get_current_rates_sc] @mfo, @sc, @currency1, @currency2, 1, @currentDate
       update @result set PairCode = @pairCode where PairCode is null; 
       select @mtRateID     = mp.CurrentRateID 
	    from dbo.MTRatePairs mp		    
	   where (mp.PairCode1 = @pairCode or mp.PairCode2 = @pairCode) and mp.[Status] = 1;

	  if ISNULL(@mtCategory,0) > 0 and ISNULL(@mtRateStatus,0) = 1 and ISNULL(@mtRateID,0) > 0
	  begin
	   select @buyRate  = case @mtCategory when 1 then mv.BuyRate1  else mv.BuyRate2  end,
	   	     @sellRate = case @mtCategory when 1 then mv.SellRate1 else mv.SellRate1 end
	     from dbo.MTRateValues mv 
	    where mv.ID       = @mtRateID 
	      and mv.[Status] = 1
	  
	  update @result set rate = @buyRate  where direction  = 1 and PairCode = @pairCode;
	  update @result set rate = @sellRate where direction != 1 and PairCode = @pairCode
	 end;
	 set @index = @index + 1
	 fetch next from currencyCursor into @currency1,@currency2
	end
	close currencyCursor
	deallocate currencyCursor

     
	select r1.curr1 +'/'+r1.curr2 PairCode, 
		  r1.scale Scale,
		  r1.rate	 BuyRate,
		  r2.rate	 SellRate 
	  from @result r1 
	  join @result r2 
	    on r2.curr1     = r1.curr1 
	   and r2.curr2     = r1.curr2 
	   and r2.direction = -1 
	 where r1.direction =  1
end

--exec [dbo].[prc_get_mt_current_rates] '220101480',2
go

grant execute on prc_get_mt_current_rates to [LB\MTClient_svc]
go

