CREATE PROCEDURE [dbo].[sync_TCI_rates]
 @cont_id bigint
AS
BEGIN
	insert into LBTCI..BANK.CURR_RATES
	select * from 
	(SELECT [CURR1],[CURR2],[DATE_VALUE],[scale],[RATE_BY1],[RATE_SELL1],[RATE_NBG],1 as fx_category FROM [RATES].[dbo].[CURR_RATES]
	  where cont_id=@cont_id and type=2
	  union
	SELECT [CURR1],[CURR2],[DATE_VALUE],[scale],[RATE_BY2],[RATE_SELL2],[RATE_NBG],2 as fx_category FROM [RATES].[dbo].[CURR_RATES]
	  where cont_id=@cont_id and type=2  
	  union
	SELECT [CURR1],[CURR2],[DATE_VALUE],[scale],[RATE_BY3],[RATE_SELL3],[RATE_NBG],3 as fx_category FROM [RATES].[dbo].[CURR_RATES]
	  where cont_id=@cont_id and type=2  
	  union
	SELECT [CURR1],[CURR2],[DATE_VALUE],[scale],[RATE_BY4],[RATE_SELL4],[RATE_NBG],4 as fx_category FROM [RATES].[dbo].[CURR_RATES]
	  where cont_id=@cont_id and type=2  
	  union
	SELECT [CURR1],[CURR2],[DATE_VALUE],[scale],[RATE_BY5],[RATE_SELL5],[RATE_NBG],5 as fx_category FROM [RATES].[dbo].[CURR_RATES]
	  where cont_id=@cont_id and type=2) t
	where not exists(select curr1 from  LBANK..BANK.CURR_RATES where curr1=t.curr1 and CURR2=t.CURR2 and fx_category=t.fx_category)
	and (select show_in_ib from dbo.CURRENCY where curr=t.CURR1)+(select show_in_ib from dbo.CURRENCY where curr=t.CURR2)=2

	update dbo.curr_rates_LBTCI set rate_by=rate_by1,
	                                  rate_sell=rate_sell1,
	                                  ora_DATE_VALUE=DATE_VALUE 
	                                  where cont_id=@cont_id and TYPE=2 and fx_category=1
	update dbo.curr_rates_LBTCI set rate_by=rate_by2,
	                                  rate_sell=rate_sell2,
	                                  ora_DATE_VALUE=DATE_VALUE  
	                                  where cont_id=@cont_id and TYPE=2 and fx_category=2
	                                  
	update dbo.curr_rates_LBTCI set rate_by=rate_by3,
	                                  rate_sell=rate_sell3,
	                                  ora_DATE_VALUE=DATE_VALUE  
	                                  where cont_id=@cont_id and TYPE=2 and fx_category=3
	update dbo.curr_rates_LBTCI set rate_by=rate_by4,
	                                  rate_sell=rate_sell4,
	                                  ora_DATE_VALUE=DATE_VALUE  
	                                  where cont_id=@cont_id and TYPE=2 and fx_category=4
	update dbo.curr_rates_LBTCI set rate_by=rate_by5,
	                                  rate_sell=rate_sell5,
	                                  ora_DATE_VALUE=DATE_VALUE  
	                                  where cont_id=@cont_id and TYPE=2 and fx_category=5
END
go

