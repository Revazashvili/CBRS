CREATE PROCEDURE [dbo].[sp_get_rates_dat_multi]
@vall varchar(3),
@dat datetime
AS
BEGIN
	SET NOCOUNT ON;
 

  CREATE TABLE [dbo].[##NBG_RATE](
	[CURR] [char](3) NOT NULL,
	[name] [nvarchar](50) NOT NULL,
	[date_value] [datetime] NULL,
	[scale] [int] NULL,
	[rate] [money] NULL,
	[id] [int] NULL
  ) ON [PRIMARY]
  insert into [##NBG_RATE] select CURR,name,@dat,scale,1,0 from dbo.CURRENCY
  
  update [##NBG_RATE] set rate=(select top 1 rate from dbo.NBG_RATE where CURR=[##NBG_RATE].CURR and date_value<=@dat order by date_value desc)
  update [##NBG_RATE] set date_value=(select top 1 date_value from dbo.NBG_RATE where CURR=[##NBG_RATE].CURR and date_value<=@dat order by date_value desc)
  update [##NBG_RATE] set rate=1 where rate is null
  update [##NBG_RATE] set date_value='01/01/2000' where date_value is null
  
  
  --select * from [##NBG_RATE]
  if ((select COUNT(*) from [##NBG_RATE]
  where [CURR]=@vall)>0)
  begin
  select [scale],[rate] from [##NBG_RATE]
  where [CURR]=@vall
  end
  else select -1 as scale
  
  
  drop table [##NBG_RATE]
  
END
go

