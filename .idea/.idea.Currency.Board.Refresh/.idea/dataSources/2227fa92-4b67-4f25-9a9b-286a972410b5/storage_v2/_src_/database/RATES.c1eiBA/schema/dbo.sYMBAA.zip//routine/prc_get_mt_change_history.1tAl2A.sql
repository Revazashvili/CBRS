create PROCEDURE [dbo].[prc_get_mt_change_history]
	@dateFrom date,
	@dateTo   date,
	@user	  varchar(64),
	@pairId	  int
AS
BEGIN
	SET NOCOUNT ON;
	declare @result  as table (
								RowNum	int,
								OperationType nvarchar(128),
								OperationTime datetime,
								OperationUser varchar(64),
								PairCode      varchar(10),
								Buy1	decimal(18,4),
								Buy2	decimal(18,4),
								Sell1 decimal(18,4),
								Sell2 decimal(18,4),

								Nbg decimal(18,4),
								CommercialBuy decimal(18,4),
								CommercialSell decimal(18,4),

								PrevBuy1 decimal(18,4),
								PrevBuy2 decimal(18,4),
								PrevSell1 decimal(18,4),
								PrevSell2 decimal(18,4),
								SourceOperationCode varchar(10)

							  )

     insert into @result (RowNum,OperationType,OperationTime,OperationUser,PairCode)
	 select -2 RowNum,
		    N'წყვილის განსაზღვრა' OperationType,
			min(v.CreateTime)	   OperationTime, 
			min(v.CreatorUser)	   OperationUser,
			p.PairCode1     	   PairCode
	   from MTRateValues v
	   join MTRatePairs p
	     on p.ID = v.PairID
	  where v.CreateTime between @dateFrom and @dateTo 
	    and (@pairId is null or v.PairID      = @pairId)
		and (@user   is null or v.CreatorUser = @user)
	    and v.[PrevRateID] is null
	    and not exists(select 1 from MTRateValues vp where vp.PairID = v.PairID and vp.ID<v.ID)
   group by p.PairCode1
 
     insert into @result (RowNum,OperationType,OperationTime,OperationUser,PairCode, Buy1, Buy2, Sell1, Sell2, Nbg, CommercialBuy, CommercialSell, PrevBuy1, PrevBuy2, PrevSell1, PrevSell2, SourceOperationCode)
	 select 1 RowNum,
		    N'კურსის რედაქტირება' OperationType,
			v.CreateTime	   OperationTime, 
			v.CreatorUser	   OperationUser,
			p.PairCode1     	   PairCode,
			v.BuyRate1,
			v.BuyRate2,
			v.SellRate1,
			v.SellRate2,
			v.[Creation_Nbg],
			v.[Creation_CommercialBuy],
		    v.[Creation_CommercialSell],
			vp.BuyRate1,
			vp.BuyRate2,
			vp.SellRate1,
			vp.SellRate2,
			v.[SourceOperationCode]
	   from MTRateValues v
	   join MTRatePairs p
	     on p.ID = v.PairID
  left join MTRateValues vp 
         on vp.id = v.[PrevRateID]
	  where v.CreateTime between @dateFrom and @dateTo 
	    and (@pairId is null or v.PairID      = @pairId)
		and (@user   is null or v.CreatorUser = @user)

     insert into @result (RowNum,OperationType,OperationTime,OperationUser,PairCode, Buy1, Buy2, Sell1, Sell2, Nbg, CommercialBuy, CommercialSell, PrevBuy1, PrevBuy2, PrevSell1, PrevSell2)
	 select 2 RowNum,
		    N'კურსის დადასტურება' OperationType,
			v.ConfirmTime	   OperationTime, 
			v.ConfirmUser	   OperationUser,
			p.PairCode1     	   PairCode,
			v.BuyRate1,
			v.BuyRate2,
			v.SellRate1,
			v.SellRate2,
			v.[Confirm_Nbg],
			v.[Confirm_CommercialBuy],
		    v.[Confirm_CommercialSell],
			vp.BuyRate1,
			vp.BuyRate2,
			vp.SellRate1,
			vp.SellRate2
	   from MTRateValues v
	   join MTRatePairs p
	     on p.ID = v.PairID
  left join MTRateValues vp 
         on vp.id = v.[PrevRateID]
	  where v.ConfirmTime between @dateFrom and @dateTo 
	    and (@pairId is null or v.PairID      = @pairId)
		and (@user   is null or v.ConfirmUser = @user)

     insert into @result (RowNum,OperationType,OperationTime,OperationUser,PairCode)
	 select -1 RowNum,
		    case m.Status when 1 then N'წყვილის გააქტიურება' else N'წყვილის შეჩერება' end OperationType,
			m.[UpdateTime]	   OperationTime, 
			m.[UpdateUser]	   OperationUser,
			p.PairCode1     	   PairCode
	   from [dbo].[MTRatePairsStatusChangeLog] m
	   join MTRatePairs p
	     on p.ID = m.PairID
	  where m.[UpdateTime] between @dateFrom and @dateTo 
	    and (@pairId is null or m.PairID      = @pairId)
		and (@user   is null or m.[UpdateUser] = @user)    

     insert into @result (RowNum,OperationType,OperationTime,OperationUser)
	 select -3 RowNum,
		    case m.ModuleStatus when 1 then N'მოდულის სტატუსის გააქტიურება' else N'მოდულის სტატუსის შეჩერება' end OperationType,
			m.[UpdateTime]	   OperationTime, 
			m.[UpdateUser]	   OperationUser
	   from [dbo].[MTRateModule_LOG] m
	  where m.[UpdateTime] between @dateFrom and @dateTo 
		and (@user   is null or m.[UpdateUser] = @user)    

	select * from @result order by OperationTime desc, RowNum desc

END
go

grant execute on prc_get_mt_change_history to [LB\TreasureRole]
go

