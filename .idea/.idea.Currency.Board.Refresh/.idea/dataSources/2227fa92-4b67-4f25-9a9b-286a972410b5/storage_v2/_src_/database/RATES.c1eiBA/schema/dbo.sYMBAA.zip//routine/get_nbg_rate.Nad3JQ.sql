CREATE PROCEDURE [dbo].[get_nbg_rate]
@curr	varchar(4),
@dat datetime
AS
BEGIN
	SET NOCOUNT ON;
	select b.CURR, b.date_value, b.scale, b.RATE
	  from (
			SELECT CURR, date_value, scale, RATE, ROW_NUMBER() over(partition by curr order by date_value desc) rnum
			  from dbo.NBG_RATE
			 where (CURR=@curr or @curr ='*ALL') and date_value<=@dat 
		   ) b
     where b.rnum=1
END
go

grant execute on get_nbg_rate to [LB\TreasureRole]
go

grant execute on get_nbg_rate to [LB\CurrencyRates_svc]
go

