CREATE FUNCTION sf_is_curr_perm(@mfo varchar(10),@sc int,@curr varchar(4))
RETURNS int
AS
BEGIN
	DECLARE @res int
  if exists(SELECT PER_TYPE from CORP_PROFILE.dbo.permited_values where PER_TYPE='UNIT_CURRENCY' and parameter=@curr and id=(select id from CORP_PROFILE.dbo.SC_PAR where mfo=@mfo and sc=@sc))
	  set @res=1
	else 
	  set @res=0
	RETURN @res

END
go

