-- =============================================
-- Author:		<david gvarishvili>
-- Description:	<currency rates auto update service>
-- =============================================
CREATE PROCEDURE  [dbo].[sp_ins_rates]
@id int,
@op_name varchar(20),
@aqt_date datetime
AS
BEGIN
SET NOCOUNT ON;
declare @type int
declare @CURR1 varchar(4)
declare @CURR2 varchar(4)
declare @scale int 
declare @RATE_BY5 money
declare @RATE_BY4 money
declare @RATE_BY3 money
declare @RATE_BY2 money
declare @RATE_BY1 money
declare @rate_market money
declare @RATE_SELL1 money
declare @RATE_SELL2 money
declare @RATE_SELL3 money
declare @RATE_SELL4 money
declare @RATE_SELL5 money
declare @RATE_NBG money,
@status int

declare @typea int
declare @CURR1a varchar(4)
declare @CURR2a varchar(4)
declare @scalea int 
declare @RATE_BY5a money
declare @RATE_BY4a money
declare @RATE_BY3a money
declare @RATE_BY2a money
declare @RATE_BY1a money
declare @rate_marketa money
declare @RATE_SELL1a money
declare @RATE_SELL2a money
declare @RATE_SELL3a money
declare @RATE_SELL4a money
declare @RATE_SELL5a money
declare @RATE_NBGa money
declare @rate11 money
declare @FX_CATEGORY int
declare @MaxControlId int

select @status=status from control where id=@id
if @status= 0 
begin
   declare curs cursor local for select type, CURR1, CURR2, scale, RATE_BY5, RATE_BY4, RATE_BY3, RATE_BY2, RATE_BY1, rate_market, RATE_SELL1, RATE_SELL2, RATE_SELL3, RATE_SELL4, RATE_SELL5, RATE_NBG from dbo.CURR_RATES_TEMP(nolock) where cont_id=@id
   open curs 
   fetch next from curs into @type, @CURR1, @CURR2, @scale, @RATE_BY5, @RATE_BY4, @RATE_BY3, @RATE_BY2, @RATE_BY1, @rate_market, @RATE_SELL1, @RATE_SELL2, @RATE_SELL3, @RATE_SELL4, @RATE_SELL5, @RATE_NBG
   while @@FETCH_STATUS=0
   begin
     set @CURR1a=null
     set @CURR2a=null
     set @scalea=null
     set @RATE_BY5a=null
     set @RATE_BY4a=null
     set @RATE_BY3a=null
     set @RATE_BY2a=null
     set @RATE_BY1a=null
     set @rate_marketa=null
     set @RATE_SELL1a=null
     set @RATE_SELL2a=null
     set @RATE_SELL3a=null
     set @RATE_SELL4a=null
     set @RATE_SELL5a=null
     set @RATE_NBGa=null
 
     select top 1 @scalea=scale, @RATE_BY5a=RATE_BY5, @RATE_BY4a=RATE_BY4, @RATE_BY3a=RATE_BY3, @RATE_BY2a=RATE_BY2, @RATE_BY1a=RATE_BY1, 
			@rate_marketa=rate_market, @RATE_SELL1a=RATE_SELL1, @RATE_SELL2a=RATE_SELL2, @RATE_SELL3a=RATE_SELL3, @RATE_SELL4a=RATE_SELL4, @RATE_SELL5a=RATE_SELL5,
			@RATE_NBGa=RATE_NBG, @MaxControlId = cont_id
     from  dbo.CURR_RATES (nolock) where type=@type and CURR1=@CURR1 and CURR2=@CURR2 and DATE_VALUE<=@aqt_date order by DATE_VALUE desc
     
     if (( @scalea!=@scale or  @RATE_BY5a!=@RATE_BY5 or  @RATE_BY4a!=@RATE_BY4 or  @RATE_BY3a!=@RATE_BY3 or  @RATE_BY2a!=@RATE_BY2 or  @RATE_BY1a!=@RATE_BY1 or  @rate_marketa!=@rate_market or  @RATE_SELL1a!=@RATE_SELL1 or  @RATE_SELL2a!=@RATE_SELL2 or  @RATE_SELL3a!=@RATE_SELL3 or  @RATE_SELL4a!=@RATE_SELL4 or  @RATE_SELL5a!=@RATE_SELL5 or  @RATE_NBGa!=@RATE_NBG or
         @scalea is null or  @RATE_BY5a is null  or  @RATE_BY4a is null  or  @RATE_BY3a is null or  @RATE_BY2a is null  or  @RATE_BY1a is null  or  @rate_marketa is null  or  @RATE_SELL1a is null  or  @RATE_SELL2a is null  or  @RATE_SELL2a is null  or  @RATE_SELL4a is null  or  @RATE_SELL5a is null  or  @RATE_NBGa is null      ) and @id > @MaxControlId)
   
     begin
       insert into dbo.CURR_RATES(type, CURR1, CURR2, DATE_VALUE, scale, RATE_BY5, RATE_BY4, RATE_BY3, RATE_BY2, RATE_BY1, rate_market, RATE_SELL1, RATE_SELL2, RATE_SELL3, RATE_SELL4, RATE_SELL5, RATE_NBG, ENT_DATE, cont_id)
                           values(@type, @CURR1, @CURR2, @aqt_date, @scale, @RATE_BY5, @RATE_BY4, @RATE_BY3, @RATE_BY2, @RATE_BY1, @rate_market, @RATE_SELL1, @RATE_SELL2, @RATE_SELL3, @RATE_SELL4, @RATE_SELL5, @RATE_NBG, GETDATE(), @id)
		
		--IMPORTANT!!! call this procedure to update LIVE RATES TABLE
        exec [dbo].[SP_UPSERT_LIVE_RATES] @type, @CURR1, @CURR2, @aqt_date, @scale, @RATE_BY5, @RATE_BY4, @RATE_BY3, @RATE_BY2, @RATE_BY1, @rate_market, @RATE_SELL1, @RATE_SELL2, @RATE_SELL3, @RATE_SELL4, @RATE_SELL5, @RATE_NBG, @id
     end  
                      
     fetch next from curs into @type, @CURR1, @CURR2, @scale, @RATE_BY5, @RATE_BY4, @RATE_BY3, @RATE_BY2, @RATE_BY1, @rate_market, @RATE_SELL1, @RATE_SELL2, @RATE_SELL3, @RATE_SELL4, @RATE_SELL5, @RATE_NBG
   end
   deallocate curs
    update control set status=1,cont_oper=@op_name,en_date=getdate() where ID=@id
	set @status=1
end
if @status=1
begin
   insert into dbo.cont_log(ID, oper, operacia) values(@id,@op_name,N'კომერციული კურსის შეცვლის დადასტურება')
   if @@error=0
   select 1  as result
   else
     select -1  as result
end
else
  select -1  as result
END
go

grant execute on sp_ins_rates to [LB\CurrencyRates_svc]
go

