CREATE PROCEDURE [dbo].[sp_get_current_nbg_rates]/*sp_get_current_nbg_rates*/
@showInIb bit = null,
@proccessing int = null
AS
BEGIN
	DECLARE @date DATE = GETDATE()

  DECLARE  @CURR_RATES_DETAIL TABLE
  (
	Currency1 CHAR(3) NULL,
	Currency2 CHAR(3) NULL,  
    Scale INT null,
	DateValue DATETIME NULL,
	RateBuy1 MONEY NULL,
	RateBuy2 MONEY NULL,
	RateBuy3 MONEY NULL,
	RateBuy4 MONEY NULL,
	RateBuy5 MONEY NULL,
	RateSell1 MONEY NULL,
	RateSell2 MONEY NULL,
	RateSell3 MONEY NULL,
	RateSell4 MONEY NULL,
	RateSell5 MONEY NULL,
	RateMarket MONEY NULL,	
	RateNBG MONEY NULL,
	Priority INT,
	Name NVARCHAR(100),
	Change MONEY NULL
	)

	INSERT INTO @CURR_RATES_DETAIL
	EXEC [RATES].[dbo].[sp_get_current_rates_all]

	DECLARE @currentdate DATE, 
			@prevdate DATE

	SELECT @currentdate =MAX(date_value)   FROM [RATES].[dbo].[NBG_RATE] WHERE cast(date_value as date) <= ISNULL( @date, GETDATE())
	SELECT @prevdate =MAX(date_value)   FROM [RATES].[dbo].[NBG_RATE] WHERE cast(date_value as date) < @currentdate


	SELECT n1.[CURR] AS Currency
		  ,n1.[date_value] AS DateValue		
		  ,n1.[rate] RateNBG
		  ,n1.[id] AS Id
		  ,@prevdate AS PreviusDateValue
		  ,case when @currentdate = @date  then   n2.rate else n1.[rate] end AS PreviusRateNBG
		  ,case when @currentdate = @date  then n2.id  else n1.[id] end AS PreviusId
		  ,case when @currentdate = @date  then  n1.rate - n2.rate  else 0 end AS Change
		  ,c.[name] AS Name
		  ,c.[scale] AS Scale
		  ,c.[priority] AS Priority
		  ,c.[status] AS Status
		  ,c.[processing] AS Processing
		  ,c.[show_in_ib] AS ShowInIb 
		  ,cd.RateBuy1
		  ,cd.RateBuy2
		  ,cd.RateBuy3
		  ,cd.RateBuy4
		  ,cd.RateBuy5
		  ,cd.RateSell1
		  ,cd.RateSell2
		  ,cd.RateSell3
		  ,cd.RateSell4
		  ,cd.RateSell5
	  FROM [RATES].[dbo].[NBG_RATE] n1
	  INNER JOIN (
				 SELECT 
				  [CURR]
				  ,MAX([date_value]) AS  date_value 
				 FROM [RATES].[dbo].[NBG_RATE] 
				 WHERE cast(date_value as date) <= @currentdate
				 GROUP BY [CURR]) m1 ON (n1.CURR = m1.CURR AND n1.date_value = m1.date_value)
	  INNER JOIN (
				  SELECT nn1.[CURR]
					  ,nn1.[date_value]
					  ,nn1.[scale]
					  ,nn1.[rate]
					  ,nn1.[id]
				  FROM [RATES].[dbo].[NBG_RATE] nn1
				  INNER JOIN (
							 SELECT 
							  [CURR], MAX([date_value]) AS  date_value 
							 FROM [RATES].[dbo].[NBG_RATE] 
							 WHERE cast(date_value as date) <= @prevdate
							 GROUP BY [CURR]) mm1 ON (nn1.CURR = mm1.CURR AND nn1.date_value = mm1.date_value)
	  ) n2 ON ( n1.CURR = n2.CURR )
	  INNER JOIN [RATES].[dbo].[CURRENCY] c ON (n1.CURR=c.CURR)
	  LEFT JOIN @CURR_RATES_DETAIL cd ON (n1.CURR = cd.Currency1 
											AND cd.Currency2='GEL')
	  WHERE c.show_in_ib = ISNULL(@showInIb, c.show_in_ib) 
			AND c.processing = ISNULL(@proccessing, c.processing)
	  ORDER BY c.priority
END
go

