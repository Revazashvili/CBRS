CREATE PROCEDURE [dbo].[sp_ins_control]
	@op_name nvarchar(128),
  @oper  nvarchar(50),
  @OP_TYPE int
AS
BEGIN
  set nocount on
  declare @id int
  insert into dbo.control(op_name,oper,OP_TYPE) values(@op_name,@oper,@OP_TYPE)
  if @@ERROR=0
  begin
    set @id=scope_identity()
    insert into dbo.cont_log(ID, oper, operacia) values(@id,@op_name,convert(varchar(3),@OP_TYPE)+N' - ოპერაციის დასადასტურებლად მომზადება')
	  SELECT @id as result
	end  
	else
	  SELECT 0 as result
END


go

grant execute on sp_ins_control to [LB\giorgi.arutinovi]
go

grant execute on sp_ins_control to TREASUREAPP
go

grant execute on sp_ins_control to [LB\TreasureRole]
go

grant execute on sp_ins_control to [LB\CurrencyRates_svc]
go

grant execute on sp_ins_control to [LB\bloomberg]
go

