CREATE PROCEDURE [dbo].[sp_cont_uar]
@id int,
@op_name varchar(20)
AS
BEGIN
SET NOCOUNT ON;
  declare @op_type int
  select @op_type=OP_TYPE from dbo.control where ID=@id

 insert into dbo.cont_log(ID, oper, operacia) values(@id,@op_name,convert(varchar(3),@OP_TYPE)+N' - ოპერაციის გაუქმება')
 update control set status=2,cont_oper=@op_name,en_date=getdate() where ID=@id
 if @@error=0
   select 1  as result
 else
   select -1  as result  
  
END
go

grant execute on sp_cont_uar to rati
go

grant execute on sp_cont_uar to TREASUREAPP
go

grant execute on sp_cont_uar to [LB\TreasureRole]
go

